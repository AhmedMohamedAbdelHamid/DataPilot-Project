# Foundation Extraction — Authoritative Decisions from Session 1

**Source document:** `Session_1/original_session1_specification.pdf`
**Extracted by:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Purpose:** record the decisions the Session 1 specification already fixed, so that
Sessions 2–5 build on them rather than silently replacing them.

Nothing in this file introduces a new decision. Where Session 1 left something open, it is
listed in Section 9 and resolved in `open_decisions_resolution_register.csv`.

---

## 1. Project definition (fixed)

| Item | Session 1 position |
|---|---|
| Product | DataPilot — Dataset Analysis & Decision Support Studio |
| Objective | Deterministic dataset profiling, AI explanation of results, rule-based chart recommendation, reproducible decision brief |
| Target users | Students, researchers, small-business analysts |
| Pilot scope | Academic and small-business CSV datasets |
| Main workflow | Upload bounded CSV → safe parse → deterministic profile → quality issues → chart rules → AI explanation → export |
| Mandatory MVP | CSV upload; safe parser; deterministic profile; issue cards; AI explanation; chart recommendation; interactive chart; export |
| First pilot | A non-expert uploads a CSV and receives reproducible quality findings and chart suggestions |
| Out of scope | Arbitrary code execution; very large/private datasets; AI-generated statistics |

## 2. Core architectural rule (fixed, non-negotiable)

> Application code computes every measurable fact. AI may explain, summarize, and suggest
> next steps, but may never calculate, alter, recompute, or invent numbers.

Session 1 §8.17 additionally fixes: the AI may not mention a column absent from
`column_profiles`, and may not state a value absent from the tool output.

## 3. Role boundaries (fixed)

| Role | Person | Owns |
|---|---|---|
| Integration Lead / Solution Architect | Ahmed Abdel Hamid | Repository, branches, API contract consistency, deployment, release checklist |
| AI & Backend Engineer | Youssef Elfeshawy | Upload/profile API, safe parser, typed schema, provider fallback, AI interpretation layer |
| Product UI & Workflow Engineer | Omar Metwally | Upload screen, dashboard, issue cards, chart gallery, question flow, export, all UI states |
| **Knowledge, Tools & Quality Engineer** | **Ahmad Essam** | **Correctness and trust layer (see §4)** |

**My ownership, restated from Session 1 §3:** approved sources and source register; domain
taxonomy; deterministic tool rules (specification); chart-recommendation rules
(specification); data-quality definitions; benchmark datasets and expected outputs;
edge-case register; not-found and failure behaviour; interpretation guardrails;
prompt-injection and invalid-input tests; ten-case evaluation; source traceability; known
limitations; production documentation for this module.

**Explicitly not mine:** frontend design, UI coding, backend server implementation, API
deployment, repository integration, cloud deployment, final system architecture ownership.

## 4. `profile_dataset()` contracts (fixed)

**Input contract (§8.4):** `dataset_name`, `parsed_table`, `encoding_metadata`,
`delimiter_metadata`, `configured_limits`, `column_hints` (optional).

**Preconditions (§8.5):** file already passed safe parsing and size/type validation;
encoding and delimiter known; configured limits supplied; no un-parsed raw bytes passed in.

**Output contract (§8.6):** `dataset_name`, `profile_version`, `status`, `rows`, `columns`,
`column_profiles`, `missing_values`, `duplicates`, `anomalies`, `quality_issues`,
`limitations`, `warnings`, `processing_metadata`, `error`.

**Column profile contract (§8.7):** `name`, `original_name`, `position`, `inferred_type`,
`nullable`, `missing_count`, `missing_percentage`, `unique_count`, `unique_percentage`,
`sample_values`, `numeric_summary`, `categorical_summary`, `date_summary`, `warnings`.

**Non-goals (§8.3):** no LLM calculation; no cleaning, de-duplication, or imputation; no
execution of dataset content; no decisions about meaning or causation.

## 5. Calculation rules (fixed)

- Row count excludes the header; column count is the number of parsed header fields.
- Missing percentage = 100 × missing_count ÷ rows; **denominator is total rows**; rounded to
  2 decimals for display, unrounded retained internally.
- Duplicate percentage = 100 × duplicate_count ÷ rows.
- Unique count = distinct **non-missing** values.
- Constant column: `unique_count ≤ 1` among non-missing → warning.
- Potential outliers: IQR rule, reported as counts and flagged values, **never as errors**.
- Standard deviation: sample convention, and the convention must be stated in output.

## 6. Type inference (fixed, conservative)

Numeric only if every non-missing value parses as a number **and** the column is not an
identifier. Numeric-looking identifiers (near-unique values and/or id/code/number name
pattern) → `identifier`, no numeric stats. Datetime only if all non-missing values parse
under one consistent verified format. Mixed-type columns classified conservatively (usually
text) with a mixed-type warning. All-missing columns → `unknown` with a warning.

## 7. Statuses, error codes, and behaviour (fixed)

**Statuses:** `success`, `success_with_warnings`, `partial`, `error`.

**Error codes (§11):** `INVALID_FILE_TYPE`, `EMPTY_DATASET`, `MALFORMED_CSV`,
`LIMIT_EXCEEDED`, `COLUMN_NOT_FOUND`, `TYPE_MISMATCH`, `INSUFFICIENT_DATA`,
`UNSUPPORTED_ANALYSIS`, `TOOL_TIMEOUT`, `PROFILE_FAILED`, `SENSITIVE_DATA_WARNING`.

**Security rules (§8.15):** cells are untrusted data, never executed; cells beginning
`= + - @` neutralized before display; samples length-capped and sanitized; no stack traces,
secrets, environment variables, or internal paths; minimum necessary sample content exposed
to the AI layer.

**Reproducibility (§8.16):** output is a pure function of (data, configured_limits, rules,
profile_version); percentile interpolation, rounding, and std convention fixed and
documented rather than left to library defaults.

## 8. Fixed rule sets carried forward unchanged

- **`recommend_chart()` rule table (§9.1)** — nine analytical needs with required fields,
  recommended chart, and guardrail. Carried forward verbatim into `chart_rules.json`.
- **Edge-case register (§10)** — 42 cases, E-01 … E-42. Carried forward and extended.
- **Interpretation guardrails (§13)** — 20 guardrails. Carried forward into
  `interpretation_guardrails.json`.
- **Not-found worked examples (§12)** — 5 examples. Carried forward into `not_found_rules.json`.
- **Known limitations (§21)** — 18 prohibited uses. Carried forward into `limitations.json`.
- **Source strategy (§5)** — approved vs candidate distinction; 7-step approval lifecycle
  (Identify → Verify → Record → Review → Approve → Use → Recheck).
- **Source register (§6)** — S-01…S-03 approved (handbook); C-04…C-09 candidates. All access
  dates recorded as `[To be verified]`.
- **Traceability model (Appendix A)** — dataset-specific vs general-guidance traceability.

## 9. Decisions Session 1 left open

D-01 … D-20 (§20) were recorded as **proposals requiring approval**, together with the
implementation decisions in §8.21. They are carried into
`open_decisions_resolution_register.csv`, where each receives a recommended resolution and
is fixed as a **proposed working rule (pending Integration Lead approval)** so that the benchmark datasets, expected outputs, and
tests in Sessions 2–5 are mutually consistent.

**Status of every such decision remains: _Proposed — requires Integration Lead approval_.**
Freezing a working default is an authoring necessity, not an approval.

---

## 10. Conflicts identified in Session 1

Two internal inconsistencies were found while extracting. Both are resolved here toward the
safest reading and flagged for team confirmation.

| # | Conflict | Safest interpretation adopted | Status |
|---|---|---|---|
| CF-1 | §1 (Executive Summary) and §4.1 describe "an edge-case register of thirty cases", but §10 presents and the acceptance criteria in §18 confirm **42** cases. | The register itself is authoritative: **42 cases**. The "thirty" wording is a drafting error in the summary text. | Team decision — no impact on rules |
| CF-2 | §11 maps *Unsupported encoding* and *Unsupported delimiter* to the code `MALFORMED_CSV`, while §10 (E-05, E-06) describes them as producing a *warning or* error. | Treat as **`MALFORMED_CSV` error when parsing cannot proceed**, and as a *warning* only when the parser recovers and the dataset still parses correctly. Both paths are specified in `error_messages.json`. | Team decision — recorded in `not_found_rules.json` |

No other conflicts were found. No Session 1 decision has been reversed.

---

## 11. Session 1 acceptance criteria status carried forward

Session 1 marked 14 criteria as satisfied by the written specification and 5 as deferred.
The 5 deferred items are the entry conditions for Sessions 2–4 and are tracked in
`Session_5/final_acceptance_matrix.csv`:

1. Three benchmark CSV datasets with data dictionaries and expected outputs — **produced in Session 2** (execution evidence pending).
2. Five core product tests implemented and evidenced — **defined in Session 2; execution pending**.
3. Ten-case evaluation executed with recorded results — **defined in Session 4; execution pending**.
4. Prompt-injection tests executed with defence evidence — **defined in Session 4; execution pending**.
5. Source access dates verified and recorded — **Session 3; verification pending**.
