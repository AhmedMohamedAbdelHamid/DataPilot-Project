# DataPilot — Final Quality Report (Session 5)

**Student:** Ahmad Essam · **Team:** Team 07 · **Role:** Knowledge, Tools & Quality Engineer
**Project:** DataPilot — Dataset Analysis & Decision Support Studio
**Version:** profile_version 0.2 · ruleset rules-2026-07-23

> **Status of evidence.** This report distinguishes throughout between what has been
> *specified and prepared* (complete) and what has been *executed and verified* (pending,
> because the integrated implementation has not yet been run). No result is reported as passed.

---

## 1. Executive summary

DataPilot lets a non-expert upload a CSV and receive a reproducible, trustworthy picture of
its quality, an explanation in plain language, and a defensible chart suggestion. My role owns
the layer that makes that trust possible: the deterministic rules, the domain knowledge, the
adversarial tests, and the evidence by which correctness is judged.

Across five sessions I have produced the full written and data foundation of that layer: a
resolved decision register (proposed, pending Integration Lead approval), a 29-term taxonomy,
three benchmark datasets with exact expected outputs, a bounded knowledge base, a traceability
model, a complete set of test plans and an evaluation suite, and production documentation
templates. What remains is source approval and execution against the built system, which is
correctly marked pending rather than fabricated.

## 2. Project overview

A non-expert can obtain a dataset but often cannot see its structure, its problems, or the
sensible next step. DataPilot profiles the data with application code, explains the results
with AI that is forbidden from inventing numbers, recommends a chart from fixed rules, and
exports a decision brief. The pilot is bounded to CSV files for students, researchers, and
small-business analysts.

## 3. My role

I own the correctness and trust layer: approved sources, taxonomy, deterministic profiling and
chart rules, data-quality definitions, benchmark datasets and expected outputs, edge cases,
error semantics, interpretation guardrails, injection and invalid-input tests, traceability,
acceptance criteria, known limitations, and this module's documentation. I do not own the
interface, the backend implementation, the API deployment, or the system architecture.

## 4. Work produced across five sessions

| Session | Produced | State |
|---|---|---|
| 1 | Specification: role, contracts, taxonomy, 42 edge cases, 20 guardrails, error codes, source strategy | Specification complete |
| 2 | 33-decision resolution register (proposed, pending approval); final taxonomy; 3 benchmark datasets; dictionaries; known-issues; exact expected profiles and chart recommendations; 5 core test plans; 3 handoffs | Specification and fixtures complete; decisions pending approval |
| 3 | Source register (pending verification); 10-file bounded knowledge base; traceability model; 73-row expected-vs-actual template; backend and chart verification plans | Specification complete; source verification and execution pending |
| 4 | 10-case evaluation plan; 12 injection, 10 formula, 23 invalid-input test plans; 15 guardrail checks; production documentation; 22 limitations; 14 release gates | Test plans and documentation complete; execution pending |
| 5 | This report; defense script; 30+ Q&A; demo checklist; final acceptance matrix | Defense preparation complete |

## 5. Deterministic correctness model

Application code computes every measurable fact; the AI may explain but never calculate, alter,
or invent. Every number is reproducible from (data, limits, rules, version). The rules are
proposed as working rules (pending Integration Lead approval) and documented: full-row duplicates, sample standard deviation, linear-interpolation
percentiles, conservative type inference with identifiers protected from summarisation, and
IQR-1.5 potential-outlier screening that never asserts an error.

## 6. Source strategy

Three approved handbook sources (S-01…S-03) and eight candidates (C-04…C-11), each labelled and
scoped. The register is pending verification: no candidate backs a product claim until the
Integration Lead approves it, and no access date is recorded until a source is actually opened.
None is fabricated.

## 7. Benchmark datasets and the expected-output strategy

Three deterministic datasets carry planted, documented issues. Their expected profiles were
**derived from the exact CSVs** under the proposed working rules (pending Integration Lead approval), so a reviewer can reproduce every
number. This is what turns "the tool seems right" into "the tool returns 65.9388 for this mean,
and here is why."

## 8. Backend and UI verification approach

The backend is to be checked field-by-field against the expected profiles within a 1e-6
tolerance (76 checks, 73 comparison rows). The UI is to be checked so that every number on
screen appears in the backend JSON and no AI sentence contains a number that does not. Both
plans are prepared; both remain pending execution until team integration.

## 9. Security and injection testing

Uploaded cells are untrusted data with no path to alter a computed value. Two live injection
payloads are planted in the survey benchmark; the correct outcome is that counts are unchanged
and the payloads appear only as samples. Formula-leading cells are neutralized by apostrophe
prefix on display and export, with two negative controls confirming ordinary values are not
over-neutralized.

## 10. Traceability

Dataset facts trace to the tool and version; general guidance traces to an approved source ID.
A general source is never cited as the origin of a dataset value. Evidence and explanation are
kept visually and semantically distinct.

## 11. Evaluation results

**Pending execution against the integrated implementation.** The suites are defined with
expected outputs; none has been run, and no case is marked passed. This is stated plainly
because the alternative — implying results that do not exist — would defeat the purpose of a
quality role.

## 12. Known limitations

22 limitations are registered. Four were discovered while authoring the benchmarks and are the
most instructive: IQR over-flags discrete columns (16 discount values); an out-of-range value
can sit inside the IQR fences (satisfaction 9); a mixed-type column suppresses numeric analysis
(age 91); a multi-format date column blocks trends. Each is now a documented limitation and a
worked AI example.

## 13. Release recommendation

Do not release the quality layer until the four blocking gates pass with recorded evidence:
deterministic output matches expected within tolerance (RQ-01), no injection alters a value
(RQ-04), no formula cell is evaluated (RQ-05), and no AI number is absent from the profile
(RQ-06). The specification is complete; release verification is not yet done, so the quality
layer is not release-ready until that evidence exists.

## 14. Future improvements

A clean-dataset fixture for the pure success path; a complementary anomaly method for discrete
and skewed data; key-based duplicate detection; a user-confirmed date-format path; a
configurable sensitive-data pattern set. All post-pilot.

## 15. Conclusion

The quality layer exists to make DataPilot trustworthy, and trust is the one property that
cannot be added later. Session 5 leaves the layer fully specified and documented, with test
plans prepared, its own limitations disclosed, and its pending verification labelled honestly.
Execution evidence remains pending until team integration. That honesty is not a gap in the
work; it is the work.
