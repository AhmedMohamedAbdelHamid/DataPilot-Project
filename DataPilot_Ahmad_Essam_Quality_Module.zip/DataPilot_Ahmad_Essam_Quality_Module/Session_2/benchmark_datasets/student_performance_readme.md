# Benchmark Dataset A — Student Performance

**File:** `benchmark_datasets/student_performance.csv`
**Shape:** 102 data rows x 12 columns (header excluded)
**Generated:** deterministically, seed `20260723`, by the authoring script owned by the
Knowledge, Tools & Quality Engineer.
**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07

## Purpose

Exercises identifier handling, missing values, duplicate detection, range violations, mixed-type classification, boolean detection and constant-column warnings in an academic context.

## Companion files

| File | Contents |
|---|---|
| `data_dictionaries/student_performance_data_dictionary.csv` | Field-by-field definition, expected type, documented range |
| `known_issues/student_performance_known_issues.csv` | Every deliberately planted issue and its expected detection |
| `expected_outputs/student_performance_expected_profile.json` | Exact expected `profile_dataset()` output |
| `expected_outputs/expected_chart_recommendations.json` | Expected `recommend_chart()` results |

## Field scope

Session 1 planned 5 fields for this dataset. This Session 2 version uses 12
fields. The additional fields are a deliberate scope extension to widen type-inference
coverage, and each is marked `No (added field)` in the `session_1_planned` column of the data
dictionary. Added fields: `age`, `gender`, `assignment_score`, `final_grade`, `scholarship_status`, `academic_year`, `notes`.

## Highlights

- **Identifier trap.** `student_id` is numeric-looking but must be classified as an
  identifier and must never receive a mean or standard deviation.
- **Mixed type.** `assignment_score` contains the text value `absent` among 101 numeric
  values, which forces conservative classification as text.
- **Range violation.** `attendance_percentage` contains `104.5`, outside the documented
  0-100 range.
- **Potential outliers.** `study_hours_per_week` contains 45 and 48, above the IQR-1.5 upper
  fence of 24.875. Both are plausible real values, which is exactly why they are reported as
  *potential* rather than as errors.
- **Duplicates.** 2 full-row duplicates (1.96% of rows).
- **Constant column.** `academic_year` holds a single value.
- **Boolean detection.** `scholarship_status` holds exactly TRUE/FALSE.

## How the expected output was produced

The expected profile was **derived from this exact CSV** using the proposed working rules (pending Integration Lead approval)
(D-06, D-08, D-09, D-10, D-11, D-12, D-21, D-22, D-24, D-29, D-30). No value was estimated.

The derivation used a specification reference generator owned by the quality role. That
generator is an authoring aid for producing expected values; it is **not** the DataPilot
product implementation. Verifying the product's actual output against this expected profile
is Session 3-4 work and is currently **Pending execution against the integrated
implementation**.

## Reproducing this dataset

The dataset is deterministic. Regenerating with seed `20260723` and the same script produces
a byte-identical file. If the file is edited, the expected profile must be regenerated and
this README's shape figures updated.
