# Benchmark Dataset B — Small-Business Sales

**File:** `benchmark_datasets/small_business_sales.csv`
**Shape:** 122 data rows x 13 columns (header excluded)
**Generated:** deterministically, seed `20260723`, by the authoring script owned by the
Knowledge, Tools & Quality Engineer.
**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07

## Purpose

Exercises date-parsing policy, categorical consistency, negative values, large values, high-cardinality free text and formula-injection neutralization in a business context.

## Companion files

| File | Contents |
|---|---|
| `data_dictionaries/small_business_sales_data_dictionary.csv` | Field-by-field definition, expected type, documented range |
| `known_issues/small_business_sales_known_issues.csv` | Every deliberately planted issue and its expected detection |
| `expected_outputs/small_business_sales_expected_profile.json` | Exact expected `profile_dataset()` output |
| `expected_outputs/expected_chart_recommendations.json` | Expected `recommend_chart()` results |

## Field scope

Session 1 planned 7 fields for this dataset. This Session 2 version uses 13
fields. The additional fields are a deliberate scope extension to widen type-inference
coverage, and each is marked `No (added field)` in the `session_1_planned` column of the data
dictionary. Added fields: `category`, `salesperson`, `discount_percentage`, `payment_method`, `status`, `notes`.

## Highlights

- **Date parsing blocked.** `order_date` mixes `2025-03-14`, `14/03/2025`, `2025/07/02`
  and `March 5, 2025`. No single format parses all values, so the column is demoted to text
  and **all trend charts are blocked**. This is the intended behaviour under D-22.
- **Formula injection.** `notes` contains four values beginning `=`, `+`, `-` and `@`. These
  are the neutralization test vectors for Session 4.
- **Negative value.** `quantity` contains `-2` with a corresponding negative revenue.
- **Large value.** `revenue` contains `58000.0`, a genuine bulk order flagged as a potential
  outlier.
- **IQR limitation demonstrated.** `discount_percentage` takes only the values 0, 5, 10 and
  15. Q3 is 5 and the upper fence is 12.5, so **every 15% discount is flagged** — 16 values in
  total. This is a deliberate, documented demonstration that the IQR rule is unsuitable for
  low-cardinality discrete columns, exactly as the D-11 caveat warns.
- **Duplicates.** 2 full-row duplicates (1.64% of rows).

## How the expected output was produced

The expected profile was **derived from this exact CSV** using the proposed working rules (pending Integration Lead approval)
(D-06, D-08, D-09, D-10, D-11, D-12, D-21, D-22, D-24, D-29, D-30). No value was estimated.

The derivation used a specification reference generator owned by the quality role. That
generator is an authoring aid for producing expected values; it is **not** the DataPilot
product implementation. Verifying the product's actual output against this expected profile
is Session 3-4 work and is currently **Pending execution against the integrated
implementation**.

## Reproducing this dataset

The dataset is deterministic. Regenerating with seed `20260723` and the same script produces
a byte-identical file. If the file is edited, the expected profile must be regenerated and
this README's shape figures updated.
