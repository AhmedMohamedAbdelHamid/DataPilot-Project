# Handoff — Integration Lead

**From:** Ahmad Essam, Knowledge, Tools & Quality Engineer
**To:** Ahmed Abdel Hamid, Integration Lead / Solution Architect
**Scope:** what the quality layer needs approved, and what it supplies to the release decision.

---

## 1. What I am asking you to approve

33 decisions are recorded in `Session_1/open_decisions_resolution_register.csv`. Every one
carries the status **"Proposed — requires Integration Lead approval"**. I have frozen a
working default for each so that the benchmark datasets, expected outputs, and tests are
mutually consistent — **freezing a default is not approval**, and any change you make will
require the expected outputs to be regenerated.

The decisions that change existing artefacts if you alter them:

| Decision | Working default | If you change it |
|---|---|---|
| D-06 profiling library | Python 3 + pandas | Expected values may shift with a different percentile or std implementation |
| D-08 missing tokens | `""`, NA, N/A, null, NULL, none, NaN, `-` | Every missing count and percentage changes |
| D-09 duplicate definition | Full-row exact match | Duplicate counts change in all three datasets |
| D-10 std convention | Sample (N−1) | Every `std` value changes |
| D-21 percentile method | Linear interpolation | Q1, Q3, median and **all IQR outlier flags** change |
| D-11 outlier method | IQR 1.5× | The anomalies block changes in all three datasets |
| D-12 high-cardinality | > 50 distinct or > 50% of rows | Column types and chart refusals change |
| D-29 severity thresholds | See `severity_model.csv` | Issue-card severities change |

**Three decisions I recommend you prioritise**, because they carry risk beyond the datasets:
D-13 (sensitive-data handling), D-14 (data retention), and D-15 (raw-data access by the AI).
These define the privacy and injection surface of the product.

## 2. Quality gates I propose for release

A gate is not passed because a module looks finished. Each requires named evidence.

| Gate | Criterion | Evidence required | Current status |
|---|---|---|---|
| QG-1 | Every deterministic field in the actual profile equals the expected profile within 1e-6 | Diff report per benchmark dataset | Pending execution |
| QG-2 | All five core product tests pass against the integrated implementation | Actual outputs + comparison | Pending execution |
| QG-3 | All ten evaluation cases execute with a recorded pass or fail | `ten_case_evaluation.csv` completed | Pending execution |
| QG-4 | No prompt-injection payload alters any deterministic value | Injection test log | Pending execution |
| QG-5 | No formula-like cell is evaluated on display or export | Neutralization test evidence | Pending execution |
| QG-6 | No AI response contains a number absent from the deterministic profile | AI guardrail review sheet | Pending execution |
| QG-7 | Every candidate source is either approved or removed from use | Signed source register | Pending your approval |
| QG-8 | Known limitations are displayed to the user, not buried | UI screenshot review by Omar | Pending execution |

**Recommendation:** QG-4, QG-5 and QG-6 should be treated as blocking. A profiling error is
a correctness bug; an injection or fabrication failure is a trust failure, and the product's
entire value proposition rests on trust.

## 3. Source strategy

- Approved sources: **S-01, S-02, S-03 only** (the three handbook resources).
- Candidate sources: **C-04 … C-11**, all labelled "Candidate — pending team-lead approval".
- No candidate may back a product claim until you approve it for a **specific documented use**.
- Access dates for all rows currently read `[To be verified]` or
  "Verification pending — access date not recorded". I have not fabricated a single date.
- Approval lifecycle: Identify → Verify → Record → Review → Approve → Use → Recheck
  (Session 1 §5.3, unchanged).
- Recheck cadence proposed at each session gate (D-28).

Full detail: `Session_3/verified_source_register.csv` (source register pending verification) and `source_approval_checklist.csv`.

## 4. Known limitations you should carry into the release decision

The full register is `Session_4/known_limitations_register.csv`. The ones that constrain
what the team may claim in the defense:

1. Potential outliers are flagged, never confirmed. The `discount_percentage` column in the
   sales benchmark flags 16 values purely because the data is discrete — a documented
   weakness of the IQR method, not a data problem.
2. A mixed-type column suppresses numeric analysis entirely. In the survey benchmark, the
   extreme age value 91 is never evaluated because one cell reads `forty-one`.
3. A value can be out of range yet inside the IQR fences. Satisfaction score 9 is caught only
   by the documented-range rule.
4. Date columns with more than one format are demoted to text and block all trend charts.
5. DataPilot shows association, never causation.
6. Nothing is cleaned, de-duplicated, or imputed automatically.
7. Type inference is a conservative inference, not a guarantee.

## 5. What I need from you

| Need | Why | Blocking |
|---|---|---|
| Approved scope for the pilot | Confirms the datasets and limits are in bounds | Yes, for Session 3 |
| Decisions D-01 … D-33 signed off | Expected outputs depend on them | Yes, for Session 3 |
| Source approvals or rejections | Candidates cannot back claims until approved | Yes, for Session 3 |
| Release constraints and target date | Determines how much evaluation fits before Session 5 | No |
| Confirmation of the error-code set with Youssef | Cross-module consistency | Yes, for Session 3 |

## 6. What I supply to you

- Measurable acceptance criteria (`Shared_Checklists/acceptance_criteria.csv`).
- Backend and UI quality checklists (`Shared_Checklists/`).
- Benchmark datasets with exact expected outputs (`Session_2/`).
- The evaluation and security test definitions (`Session_4/`).
- The known-limitations register and release checklist (`Session_4/`).
- A final acceptance matrix for the release decision (`Session_5/final_acceptance_matrix.csv`).

## 7. Escalation

Per the handbook I will contact Dr. Ahmed if: an acceptance rule is unclear; a security or
privacy issue is identified that the team cannot resolve; the team is blocked for more than
24 hours after documenting attempts; or a requested feature would require the AI to produce
statistics directly, which would violate the project's core principle.
