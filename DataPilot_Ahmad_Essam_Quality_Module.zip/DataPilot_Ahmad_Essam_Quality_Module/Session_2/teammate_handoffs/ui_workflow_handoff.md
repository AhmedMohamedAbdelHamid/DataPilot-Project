# Handoff — Product UI & Workflow Engineer

**From:** Ahmad Essam, Knowledge, Tools & Quality Engineer
**To:** Omar Metwally, Product UI & Workflow Engineer
**Scope:** the wording, labels, and display rules the interface must honour so that evidence
stays distinguishable from explanation.

I do not design the interface. Everything below is about *what must be true* of what the user
reads, not how it should look.

---

## 1. The one rule that shapes every screen

A user must always be able to tell **which numbers came from the deterministic profile** and
**which text came from the AI**. If those two blur together, a user cannot tell a measurement
from a paraphrase, and the product's core claim collapses.

Practical implication: deterministic values and AI explanation should never share a visual
treatment, and the AI explanation should carry a persistent label such as
**"AI explanation — based on the profile above"**.

## 2. Screen states

| State | Trigger | Must show | Must not show |
|---|---|---|---|
| Idle | No file selected | Accepted format (CSV), size limit (10 MB), row/column limits | Any sample result |
| Loading | Upload or profiling in progress | Progress indicator, cancel option | Partial numbers |
| Success | `status = success` | Full profile, charts, AI explanation, limitations | Warnings block (there are none) |
| Success with warnings | `status = success_with_warnings` | Everything above **plus** the warnings block | Warnings collapsed by default |
| Partial | `status = partial` | Profiled columns, plus an explicit list of skipped columns and why | Any value for a skipped column |
| Empty | Dataset has no data rows | `EMPTY_DATASET` message, retry | A zero-filled profile |
| Validation error | Bad file type or limit exceeded | Code-specific message, the actual limit, retry | Stack trace or internal path |
| Provider error | AI layer unavailable | **The deterministic profile still renders**, with a note that the explanation is unavailable | An apology that hides the working profile |
| Not found | Requested column absent | Message plus the list of available fields | An invented value |
| Retry | After a retryable error | Clear retry affordance | Silent auto-retry that changes results |

**Important:** if the AI explanation fails, the profile is still valid and must still be
shown. The deterministic layer does not depend on the AI layer.

## 3. User-facing labels

| Concept | UI label | Never call it |
|---|---|---|
| `inferred_type` | "Detected type" | "Type" (implies certainty) |
| `identifier` | "ID column — not summarized" | "Number" |
| `missing_count` | "Missing values" | "Errors" |
| `duplicates` | "Duplicate rows" | "Bad rows" |
| `anomalies` | "Potential outliers" | "Outliers" / "Errors" / "Anomalies detected" |
| `quality_issues` | "Quality issues" | "Problems found" / "Data errors" |
| `warnings` | "Things to check" | "Failures" |
| `limitations` | "What this analysis cannot tell you" | (do not hide) |
| Deterministic values | "Measured" or "Evidence" | "AI found" |
| AI text | "AI explanation" | "Analysis" / "Results" |

The word **"potential"** in "Potential outliers" is not optional. It is the difference between
a defensible statement and a false accusation about someone's data.

## 4. Issue-card catalogue

Full machine-readable version: `Shared_Checklists/issue_card_catalogue.csv`.

| Issue type | Card title | Body pattern | Severity source |
|---|---|---|---|
| `missing_values` | Missing values in *{column}* | "{n} of {rows} rows ({pct}%) have no value." | D-29 thresholds |
| `duplicate_rows` | Duplicate rows | "{n} of {rows} rows ({pct}%) repeat an earlier row. Nothing has been removed." | D-29 |
| `potential_outliers` | Potential outliers in *{column}* | "{n} value(s) fall outside the IQR range [{low}, {high}]. These may be genuine." | Always low |
| `value_out_of_documented_range` | Values outside expected range in *{column}* | "{n} value(s) fall outside the documented range {min}–{max}." | Medium |
| `negative_value_in_non_negative_field` | Negative values in *{column}* | "{n} negative value(s) in a field expected to be non-negative." | Medium |
| `constant_column` | *{column}* has no variation | "Every row holds the same value." | Low |
| `high_cardinality` | *{column}* has many distinct values | "{n} distinct values across {rows} rows; category charts are not offered." | Low |
| `mixed_type` | Mixed data types in *{column}* | "{n} value(s) are not numbers, so no statistics are calculated for this column." | Medium |
| `mixed_date_formats` | Inconsistent dates in *{column}* | "Dates use more than one format, so time-based charts are not available." | Medium |
| `formula_like_content` | Formula-like text in *{column}* | "{n} cell(s) begin with = + - or @. They are shown as text and never calculated." | High |

### Severity labels

| Severity | Label | Meaning |
|---|---|---|
| `low` | "Minor" | Worth knowing; unlikely to change conclusions |
| `medium` | "Review" | Could change conclusions; user should look |
| `high` | "Important" | Likely to affect any analysis; user should act |

Severity is computed deterministically (D-29), never assigned by the AI.

## 5. Warning wording (exact strings)

```
all_missing            → "Every value in this column is missing, so it cannot be analysed."
constant_column        → "Every row has the same value, so this column shows no variation."
high_cardinality       → "This column has {n} distinct values. Category charts are not offered."
mixed_type             → "Some values are not numbers, so statistics are not calculated."
mixed_date_formats     → "Dates are written in more than one format, so time analysis is unavailable."
inconsistent_spelling  → "Some labels differ only by capitalisation and may be the same category."
formula_like_content   → "Some cells start with = + - or @. They are displayed as text and never calculated."
identifier_not_summarized → "This looks like an ID column, so it is not summarised as a measurement."
encoding_fallback      → "The file's text encoding was detected, not declared. Check for unusual characters."
ragged_rows            → "Some rows had a different number of fields than the header."
```

## 6. Error wording (exact strings)

```
INVALID_FILE_TYPE      → "DataPilot reads CSV files. Please upload a .csv file."
EMPTY_DATASET          → "This file has no data rows to analyse."
MALFORMED_CSV          → "This file could not be read as CSV. {detail}"
LIMIT_EXCEEDED         → "This file is larger than the current limit of {limit}."
COLUMN_NOT_FOUND       → "There is no column named '{requested}'. Available fields: {list}."
TYPE_MISMATCH          → "That calculation is not available for a {type} column."
INSUFFICIENT_DATA      → "There is not enough data here for a reliable answer."
UNSUPPORTED_ANALYSIS   → "DataPilot does not support that analysis."
TOOL_TIMEOUT           → "Analysis took too long. Please try again."
PROFILE_FAILED         → "Something went wrong while analysing this file. Please try again."
SENSITIVE_DATA_WARNING → "This dataset may contain personal or sensitive values."
```

No message reveals a stack trace, file path, provider name, or internal identifier.

## 7. Not-found behaviour

When a user asks about a column that does not exist:

1. State plainly that the field was not found — name the field they asked for.
2. List the available fields, ideally the ones closest in type to what they wanted.
3. Ask them to choose.
4. **Never** show a placeholder, a zero, or a dash where the value would have been.

Worked example the UI should match:

> **Field not found**
> There is no column named "profit" in this dataset.
> Available numeric fields: `quantity`, `unit_price`, `discount_percentage`, `revenue`.
> Select a field to analyse.

The same pattern applies to a misspelled field: suggest the closest available name, but do
not silently substitute it.

## 8. Chart display rules

- Every chart carries its **aggregation in the axis label** ("Mean exam score", not "Exam score").
- Every recommendation carries a short **reason** naming the fields and their types.
- When `recommend_chart()` returns `no_chart`, show the **reason**, not an empty panel.
  Example: "A trend chart needs a date column. `order_date` uses more than one date format,
  so it is being read as text."
- Never label a scatter plot in causal terms. "Study hours vs exam score" is acceptable;
  "Effect of study hours on exam score" is not.
- Charts exclude missing values; the count excluded must be stated near the chart.
- Pie charts are limited to a small number of categories that sum to a meaningful whole;
  prefer bar charts (Session 1 §9.2).

## 9. Traceability fields to display

Each deterministic value should be attributable on demand:

```
dataset_name, dataset_version, tool = profile_dataset, profile_version,
ruleset_version, run_id, column, calculation_rule
```

A compact treatment — an information affordance on each card revealing "Measured by
`profile_dataset` v0.2, ruleset `rules-2026-07-23`, run `run-20260723-101500-A1B2`" — satisfies
this without cluttering the page.

For general guidance shown in the interface (definitions, method explanations), the source ID
and approval status must be visible, and a candidate source must be visibly marked as not yet
approved.

## 10. Sample-value display

- At most 3 samples per column, each at most 60 characters, ellipsis on truncation.
- Values beginning `=`, `+`, `-`, `@` are shown with a leading apostrophe and must never be
  evaluated by any spreadsheet-like component or on export.
- `<` and `>` are escaped; no cell content is ever rendered as HTML.
- Free-text samples from the survey benchmark include planted injection strings. They must
  render as inert, visibly-quoted text.

## 11. Sample responses to build against

| Scenario | Fixture | File |
|---|---|---|
| Success with warnings | `student_performance.csv` | `expected_outputs/student_performance_expected_profile.json` |
| Warning-heavy | `research_survey.csv` | `expected_outputs/research_survey_expected_profile.json` |
| Formula content | `small_business_sales.csv` | `expected_outputs/small_business_sales_expected_profile.json` |
| Error | — | Session 1 §8.20 example error output |
| Partial | — | `Session_3/success_warning_partial_error_verification.md` |
| Chart refusals | all three | `expected_outputs/expected_chart_recommendations.json` |

## 12. What I need from you

| Need | Why |
|---|---|
| The planned result-card layout | So I can check that evidence and explanation are visually separable |
| Your error-state requirements | To confirm my wording fits the available space |
| The chart interaction flow | To confirm `no_chart` reasons have somewhere to appear |
| Where limitations will appear | They must be visible, not hidden behind a link |

## 13. Verification I will run later

`Shared_Checklists/ui_quality_checklist.csv` — 28 checks, currently all
**"Pending execution against the integrated implementation."** The two that matter most:

- **Every number visible on screen appears in the backend JSON.** I will compare rendered
  values against the profile field by field.
- **No AI sentence contains a number absent from that JSON.**
