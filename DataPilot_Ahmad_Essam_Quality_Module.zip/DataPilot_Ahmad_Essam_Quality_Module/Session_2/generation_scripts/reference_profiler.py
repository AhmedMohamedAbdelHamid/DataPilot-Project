"""
Expected-output generator (specification reference implementation).

PURPOSE: derive the EXACT expected values for the benchmark datasets, so that
`*_expected_profile.json` contains real numbers rather than estimates.

THIS IS NOT THE PRODUCT IMPLEMENTATION. It is an authoring aid owned by the
Knowledge, Tools & Quality Engineer. The DataPilot backend implementation of
profile_dataset() is owned by the AI & Backend Engineer and remains
"Pending execution against the integrated implementation."

Proposed working rules applied, pending Integration Lead approval (see open_decisions_resolution_register.csv):
  D-06 Python 3 + pandas            D-10 sample std (N-1, ddof=1)
  D-08 missing tokens (below)       D-11 IQR 1.5x, potential outliers only
  D-09 full-row duplicates          D-12 high cardinality: >50 distinct or >50% of rows
  D-21 percentiles: linear interpolation (numpy default)
  Percentage denominator = total rows; displayed rounded to 2 decimals.
"""
import csv, json, math, os, re, statistics
from datetime import datetime

BASE = "DataPilot_Ahmad_Essam_Quality_Module/Session_2"
DATA = os.path.join(BASE, "benchmark_datasets")
OUT = os.path.join(BASE, "expected_outputs")
os.makedirs(OUT, exist_ok=True)

PROFILE_VERSION = "0.2"
RULESET_VERSION = "rules-2026-07-23"

# D-08 — missing-value token set (case-insensitive, after strip)
MISSING_TOKENS = {"", "na", "n/a", "null", "none", "nan", "-"}
BOOL_SETS = [
    {"true", "false"}, {"yes", "no"}, {"0", "1"}, {"y", "n"}, {"t", "f"},
]
ID_NAME_PATTERN = re.compile(r"(^|_)(id|code|number|no|ref|key)($|_)", re.I)
DATE_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%Y/%m/%d", "%B %d, %Y", "%m-%d-%Y", "%d-%m-%Y"]
HIGH_CARD_ABS = 50
HIGH_CARD_RATIO = 0.5
SAMPLE_CAP = 3
SAMPLE_LEN_CAP = 60
FORMULA_PREFIXES = ("=", "+", "-", "@")


def is_missing(v):
    return str(v).strip().lower() in MISSING_TOKENS


def as_number(v):
    s = str(v).strip().replace(",", "")
    if s == "":
        return None
    try:
        f = float(s)
        if math.isnan(f) or math.isinf(f):
            return None
        return f
    except ValueError:
        return None


def parse_date_fmt(values):
    """Return the single format that parses ALL values, else None."""
    for fmt in DATE_FORMATS:
        try:
            for v in values:
                datetime.strptime(str(v).strip(), fmt)
            return fmt
        except ValueError:
            continue
    return None


def pct(n, d):
    return round(100.0 * n / d, 2) if d else 0.0


def quantile_linear(sorted_vals, q):
    """Linear interpolation (numpy default) — fixed by D-21 (proposed working rule, pending approval)."""
    n = len(sorted_vals)
    if n == 0:
        return None
    if n == 1:
        return float(sorted_vals[0])
    pos = (n - 1) * q
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return float(sorted_vals[int(pos)])
    frac = pos - lo
    return float(sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * frac)


def sanitize_sample(v):
    s = str(v)
    if s[:1] in FORMULA_PREFIXES:
        s = "'" + s            # neutralization: prefix with apostrophe
    s = s.replace("<", "&lt;").replace(">", "&gt;")
    if len(s) > SAMPLE_LEN_CAP:
        s = s[:SAMPLE_LEN_CAP - 1] + "\u2026"
    return s


def profile(dataset_name, path, ranges=None, dataset_version="1.0"):
    ranges = ranges or {}
    with open(path, newline="", encoding="utf-8") as f:
        reader = list(csv.reader(f))
    header = reader[0]
    data = reader[1:]
    rows = len(data)
    columns = len(header)

    # ---- duplicates (D-09 full-row) ----
    seen, dup_count = set(), 0
    for r in data:
        key = tuple(r)
        if key in seen:
            dup_count += 1
        else:
            seen.add(key)

    col_profiles, warnings, quality_issues, anomalies = [], [], [], {}
    missing_values = {}

    for pos, name in enumerate(header):
        raw = [r[pos] if pos < len(r) else "" for r in data]
        present = [v for v in raw if not is_missing(v)]
        missing_count = rows - len(present)
        distinct = sorted(set(str(v).strip() for v in present))
        unique_count = len(distinct)
        lower_distinct = {d.lower() for d in distinct}

        nums = [as_number(v) for v in present]
        numeric_ok = [n for n in nums if n is not None]
        all_numeric = len(numeric_ok) == len(present) and len(present) > 0
        some_numeric = 0 < len(numeric_ok) < len(present)

        colw = []
        inferred = "unknown"
        numeric_summary = None
        categorical_summary = None
        date_summary = None

        if len(present) == 0:
            inferred = "unknown"
            colw.append("all_missing: no values to summarize")
        elif unique_count == 2 and lower_distinct in BOOL_SETS:
            inferred = "boolean"
        elif ID_NAME_PATTERN.search(name) and unique_count / max(len(present), 1) >= 0.9:
            inferred = "identifier"
            colw.append("numeric-looking identifier: not summarized as a measure"
                        if all_numeric else "identifier column: not summarized as a measure")
        elif all_numeric:
            inferred = "numeric"
        elif some_numeric:
            inferred = "text"
            colw.append(f"mixed_type: {len(present) - len(numeric_ok)} non-numeric value(s) "
                        f"among {len(numeric_ok)} numeric value(s); classified conservatively as text")
        else:
            fmt = parse_date_fmt(present)
            if fmt:
                inferred = "datetime"
            else:
                # date-like values that do not share ONE consistent format
                partial = sum(1 for v in present if parse_date_fmt([v]))
                if partial >= 0.6 * len(present):
                    inferred = "text"
                    colw.append(
                        f"mixed_date_formats: {partial} of {len(present)} values look like dates "
                        f"but do not parse under one consistent format; not treated as datetime")
                elif unique_count > HIGH_CARD_ABS or unique_count / rows > HIGH_CARD_RATIO:
                    inferred = "text"
                else:
                    inferred = "categorical"

        # constant / high cardinality
        if unique_count <= 1 and len(present) > 0:
            colw.append("constant_column: single distinct value; carries no variation")
        if inferred in ("categorical", "text") and (
                unique_count > HIGH_CARD_ABS or unique_count / rows > HIGH_CARD_RATIO):
            colw.append(f"high_cardinality: {unique_count} distinct values "
                        f"({pct(unique_count, rows)}% of rows)")

        # inconsistent capitalization
        if inferred in ("categorical", "text") and len({d.lower() for d in distinct}) < unique_count:
            colw.append("inconsistent_category_spelling: labels differ only by capitalization")

        # formula-like content
        formula_hits = [v for v in present if str(v)[:1] in FORMULA_PREFIXES and as_number(v) is None]
        if formula_hits:
            colw.append(f"formula_like_content: {len(formula_hits)} cell(s) begin with = + - @ "
                        f"and are neutralized before display")

        # summaries
        if inferred == "numeric":
            s = sorted(numeric_ok)
            n = len(s)
            q1 = quantile_linear(s, 0.25)
            q3 = quantile_linear(s, 0.75)
            numeric_summary = {
                "count": n,
                "mean": round(sum(s) / n, 4),
                "median": round(quantile_linear(s, 0.5), 4),
                "min": s[0], "max": s[-1],
                "q1": round(q1, 4), "q3": round(q3, 4),
                "std": round(statistics.stdev(s), 4) if n > 1 else 0.0,
                "std_convention": "sample (N-1)",
                "percentile_method": "linear",
            }
            if n >= 4:
                iqr = q3 - q1
                low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
                flagged = [x for x in s if x < low or x > high]
                if flagged:
                    anomalies[name] = {
                        "potential_outliers": len(flagged),
                        "method": "IQR-1.5",
                        "lower_fence": round(low, 4), "upper_fence": round(high, 4),
                        "flagged_values": sorted(set(flagged)),
                        "note": "Potential outliers only; not confirmed errors.",
                    }
            # documented range check
            if name in ranges:
                lo_r, hi_r = ranges[name]
                out = [x for x in s if x < lo_r or x > hi_r]
                if out:
                    quality_issues.append({
                        "type": "value_out_of_documented_range", "column": name,
                        "severity": "medium",
                        "evidence": f"{len(out)} value(s) outside documented range "
                                    f"{lo_r}\u2013{hi_r}: {sorted(set(out))}",
                    })
            neg = [x for x in s if x < 0]
            if neg and name in ("quantity", "unit_price", "study_hours_per_week",
                                "attendance_percentage", "revenue"):
                quality_issues.append({
                    "type": "negative_value_in_non_negative_field", "column": name,
                    "severity": "medium",
                    "evidence": f"{len(neg)} negative value(s): {sorted(set(neg))}",
                })
        elif inferred == "categorical":
            freq = {}
            for v in present:
                k = str(v).strip()
                freq[k] = freq.get(k, 0) + 1
            top = sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))[:10]
            categorical_summary = {"distinct": unique_count,
                                   "top_categories": [{"value": k, "count": c} for k, c in top]}
        elif inferred == "datetime":
            fmt = parse_date_fmt(present)
            ds = sorted(datetime.strptime(str(v).strip(), fmt) for v in present)
            date_summary = {"format": fmt, "min": ds[0].date().isoformat(),
                            "max": ds[-1].date().isoformat(),
                            "span_days": (ds[-1] - ds[0]).days}
        elif inferred == "text":
            lens = [len(str(v)) for v in present]
            categorical_summary = {"distinct": unique_count,
                                   "min_length": min(lens), "max_length": max(lens),
                                   "mean_length": round(sum(lens) / len(lens), 2)}

        missing_values[name] = {"count": missing_count, "percentage": pct(missing_count, rows)}
        if missing_count > 0:
            sev = "high" if missing_count / rows > 0.3 else (
                "medium" if missing_count / rows > 0.1 else "low")
            quality_issues.append({
                "type": "missing_values", "column": name, "severity": sev,
                "evidence": f"{missing_count} of {rows} rows ({pct(missing_count, rows)}%)",
            })

        for w in colw:
            warnings.append(f"[{name}] {w}")

        col_profiles.append({
            "name": name, "original_name": name, "position": pos,
            "inferred_type": inferred,
            "nullable": missing_count > 0,
            "missing_count": missing_count,
            "missing_percentage": pct(missing_count, rows),
            "unique_count": unique_count,
            "unique_percentage": pct(unique_count, rows),
            "sample_values": [sanitize_sample(v) for v in present[:SAMPLE_CAP]],
            "numeric_summary": numeric_summary,
            "categorical_summary": categorical_summary,
            "date_summary": date_summary,
            "warnings": colw,
        })

    if dup_count:
        quality_issues.append({
            "type": "duplicate_rows", "severity": "medium" if dup_count / rows > 0.01 else "low",
            "evidence": f"{dup_count} of {rows} rows ({pct(dup_count, rows)}%)",
        })
    for name, a in anomalies.items():
        quality_issues.append({
            "type": "potential_outliers", "column": name, "severity": "low",
            "evidence": f"{a['potential_outliers']} value(s) outside IQR-1.5 fences "
                        f"[{a['lower_fence']}, {a['upper_fence']}]",
        })

    status = "success_with_warnings" if warnings else "success"

    limitations = [
        "Potential outliers are flagged by the IQR-1.5 rule; they are not confirmed errors.",
        "Inferred column types are conservative inferences, not guarantees.",
        "Missing values are counted and reported; they are never imputed automatically.",
        "Duplicate rows are reported; they are never removed automatically.",
        "Percentages use total row count as the denominator.",
    ]

    return {
        "dataset_name": dataset_name,
        "dataset_version": dataset_version,
        "profile_version": PROFILE_VERSION,
        "ruleset_version": RULESET_VERSION,
        "status": status,
        "rows": rows,
        "columns": columns,
        "column_names": header,
        "column_profiles": col_profiles,
        "missing_values": missing_values,
        "duplicates": {"count": dup_count, "percentage": pct(dup_count, rows),
                       "definition": "full-row match (D-09)"},
        "anomalies": anomalies,
        "quality_issues": quality_issues,
        "limitations": limitations,
        "warnings": warnings,
        "processing_metadata": {
            "tool": "profile_dataset",
            "version": PROFILE_VERSION,
            "ruleset_version": RULESET_VERSION,
            "run_id": "EXPECTED-REFERENCE",
            "note": "Expected values derived by the specification reference generator. "
                    "Actual product output: Pending execution against the integrated implementation.",
        },
        "error": None,
    }


JOBS = [
    ("student_performance", "student_performance.csv",
     {"attendance_percentage": (0, 100), "assignment_score": (0, 100), "exam_score": (0, 100)}),
    ("small_business_sales", "small_business_sales.csv",
     {"discount_percentage": (0, 100)}),
    ("research_survey", "research_survey.csv",
     {"satisfaction_score": (1, 5)}),
]

if __name__ == "__main__":
    for name, fn, ranges in JOBS:
        p = profile(name, os.path.join(DATA, fn), ranges)
        out = os.path.join(OUT, f"{name}_expected_profile.json")
        with open(out, "w", encoding="utf-8") as f:
            json.dump(p, f, indent=2, ensure_ascii=False)
        print(f"{name}: rows={p['rows']} cols={p['columns']} "
              f"dups={p['duplicates']['count']} status={p['status']} "
              f"issues={len(p['quality_issues'])} warnings={len(p['warnings'])}")
