# Generation Scripts

These two scripts are the authoring aids that produced the benchmark datasets and their exact
expected outputs. They are included so my work can be independently reproduced and checked.

- `gen_datasets.py` — deterministically generates the three benchmark CSVs (seed 20260723) with
  all planted issues documented in the known-issues registers.
- `reference_profiler.py` — the **specification reference implementation**. It applies the proposed
  working rules (pending Integration Lead approval) (D-06, D-08, D-09, D-10, D-11, D-12, D-21, D-22, D-24, D-29, D-30) to derive the exact
  expected profiles.

**Important:** `reference_profiler.py` is NOT the DataPilot product. It is an authoring aid owned
by the Knowledge, Tools & Quality Engineer for generating expected values. The product's
`profile_dataset()` is implemented by the AI & Backend Engineer, and verifying it against these
expected outputs is Session 3–4 work, currently *Pending execution against the integrated
implementation*.

To reproduce:
```
python3 gen_datasets.py          # regenerates the three CSVs (byte-identical)
python3 reference_profiler.py     # regenerates the expected profile JSONs
```
