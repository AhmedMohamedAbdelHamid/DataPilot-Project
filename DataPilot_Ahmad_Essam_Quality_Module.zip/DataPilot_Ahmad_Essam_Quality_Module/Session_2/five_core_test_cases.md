# Five Core Product Tests — Session 2 Specification

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07  
**Status of all five tests:** *Pending execution against the integrated implementation.*  
**Expected values source:** derived exactly from the Session 2 benchmark CSVs.

These are test *definitions with expected results*. None has been executed, and no result below is claimed as observed.

---

## T01 — A clean, well-formed dataset profiles correctly and completely.

**Requirement:** MVP: deterministic profile. S1 §8.11 success behaviour.  
**Fixture:** `student_performance.csv (used for shape, identifier and boolean checks)`  
**Preconditions:** File under D-01/D-02/D-03 limits; UTF-8; comma-delimited; safe parse succeeded.

**Steps**

1. Submit the fixture to profile_dataset().
2. Compare every field against student_performance_expected_profile.json.
3. Compare the AI explanation against the guardrails.

**Expected deterministic result**

rows = 102; columns = 12; student_id inferred_type = identifier with numeric_summary = null; scholarship_status inferred_type = boolean; academic_year raises a constant_column warning; age numeric_summary mean = 20.2843, median = 20.0, std = 1.3525.

**Expected status:** `success_with_warnings`

**Expected warnings:** 5 warnings: identifier note on student_id; inconsistent capitalization on gender and department; mixed_type on assignment_score; constant_column on academic_year.

**Expected issue cards:** 7 issue cards (4 missing_values, 1 value_out_of_documented_range, 1 duplicate_rows, 1 potential_outliers).

**Expected chart behaviour:** Category comparison and distribution charts offered; trend chart refused because no datetime column exists.

**Acceptance criterion:** Every deterministic field equals the expected value within tolerance 1e-6 (D-31). The AI explanation contains no numeric value absent from the profile.

**Evidence to capture later:** Actual profile JSON; AI explanation transcript; diff report against the expected profile.

**Owner:** Ahmad Essam (expected output) / Youssef Elfeshawy (execution)  
**Execution session:** Session 3-4  
**Current status:** Pending execution against the integrated implementation

---

## T02 — Missing values are counted exactly and never imputed.

**Requirement:** S1 §8.8 missing rules; guardrails 3 and 16.  
**Fixture:** `research_survey.csv (includes a 100% missing column)`  
**Preconditions:** As T01.

**Steps**

1. Profile the fixture.
2. Check per-column missing counts and percentages.
3. Confirm the all-missing column is typed unknown.
4. Ask the AI to summarize and confirm it does not fill gaps.

**Expected deterministic result**

satisfaction_score missing_count = 4 (4.17%); usage_frequency = 3 (3.12%); comments = 22 (22.92%); optional_follow_up = 96 (100.0%) with inferred_type = unknown and no summaries. Denominator is 96 total rows in every case.

**Expected status:** `success_with_warnings`

**Expected warnings:** all_missing warning on optional_follow_up; mixed_type on age; mixed_date_formats on submission_date; high_cardinality on comments; constant_column on consent_given; capitalization warnings on four categorical columns.

**Expected issue cards:** missing_values cards for satisfaction_score (low), usage_frequency (low), comments (medium), optional_follow_up (high, 100%).

**Expected chart behaviour:** A missing-values bar chart may be offered using deterministic counts only.

**Acceptance criterion:** All missing counts equal the expected values. No imputed or estimated value appears in either the profile or the AI explanation.

**Evidence to capture later:** Actual profile JSON; AI explanation transcript.

**Owner:** Ahmad Essam (expected output) / Youssef Elfeshawy (execution)  
**Execution session:** Session 3-4  
**Current status:** Pending execution against the integrated implementation

---

## T03 — Duplicate rows are detected, reported, and never removed automatically.

**Requirement:** S1 §8.8 duplicate rules; D-09; guardrail 6.  
**Fixture:** `student_performance.csv (2 duplicates) and small_business_sales.csv (2 duplicates)`  
**Preconditions:** As T01.

**Steps**

1. Profile both fixtures.
2. Compare duplicate counts and percentages.
3. Confirm row counts are unchanged.
4. Confirm the AI asks for confirmation before suggesting removal.

**Expected deterministic result**

student_performance: duplicates.count = 2, percentage = 1.96, rows still 102. small_business_sales: duplicates.count = 2, percentage = 1.64, rows still 122. Definition recorded as full-row match (D-09).

**Expected status:** `success_with_warnings`

**Expected warnings:** No duplicate-specific warning; duplicates are reported as an issue card.

**Expected issue cards:** One duplicate_rows card per dataset, severity medium (above the 1% threshold in D-29).

**Expected chart behaviour:** Not applicable to this test.

**Acceptance criterion:** Duplicate counts equal the expected values, row counts are unchanged, and no output states that duplicates were removed.

**Evidence to capture later:** Actual profile JSON for both fixtures; AI explanation transcript.

**Owner:** Ahmad Essam (expected output) / Youssef Elfeshawy (execution)  
**Execution session:** Session 3-4  
**Current status:** Pending execution against the integrated implementation

---

## T04 — Potential outliers are flagged as potential, with the method stated, and never described as confirmed errors.

**Requirement:** S1 §8.10; D-11; D-21; guardrails 2 and 17.  
**Fixture:** `student_performance.csv (study_hours_per_week), small_business_sales.csv (discount_percentage), research_survey.csv (satisfaction_score)`  
**Preconditions:** As T01. At least 4 non-missing numeric values per column.

**Steps**

1. Profile all three fixtures.
2. Compare flagged values and fences.
3. Confirm the satisfaction_score value 9 is NOT in anomalies.
4. Confirm the AI language is non-committal.

**Expected deterministic result**

study_hours_per_week: 2 potential outliers (45, 48), fences [-2.125, 24.875]. discount_percentage: 16 potential outliers (all 15% values), fences [-7.5, 12.5]. revenue: 9 potential outliers, fences [-2388.0687, 4951.7812]. satisfaction_score: 0 potential outliers, because the value 9 lies inside the upper fence of 9.5 and is instead caught by the documented-range rule.

**Expected status:** `success_with_warnings`

**Expected warnings:** None specific to outliers.

**Expected issue cards:** potential_outliers cards at severity low, each stating the method and fences; a separate value_out_of_documented_range card at severity medium for satisfaction_score.

**Expected chart behaviour:** A histogram may be offered with a disclosure that extreme values affect the axis.

**Acceptance criterion:** Flagged values and fences match exactly. No output word implies the values are errors. The method name IQR-1.5 appears with every flag.

**Evidence to capture later:** Actual profile JSON for three fixtures; AI explanation transcript.

**Owner:** Ahmad Essam (expected output) / Youssef Elfeshawy (execution)  
**Execution session:** Session 3-4  
**Current status:** Pending execution against the integrated implementation

---

## T05 — Chart recommendations follow the deterministic rule table, including refusing to recommend a chart when the rules are not satisfied.

**Requirement:** S1 §9.1 rule table and §9.2 selection principles; D-16; D-22; guardrail 12.  
**Fixture:** `small_business_sales.csv (blocked trend) and student_performance.csv (valid comparison)`  
**Preconditions:** A completed profile is available for the dataset.

**Steps**

1. Ask 'Show revenue by month' against the sales fixture.
2. Ask 'Compare exam scores by department' against the student fixture.
3. Ask 'Compare revenue by note text'.
4. Compare each result against expected_chart_recommendations.json.

**Expected deterministic result**

Query 1 returns no_chart because order_date is text with a mixed_date_formats warning, not datetime. Query 2 returns bar_chart with aggregation = mean and a stated reason. Query 3 returns no_chart because notes has 75 distinct values, above the D-12 high-cardinality threshold.

**Expected status:** `success (recommendation produced) or no_chart with a reason`

**Expected warnings:** High-cardinality warning surfaced for query 3.

**Expected issue cards:** Not applicable; chart rules do not emit issue cards.

**Expected chart behaviour:** Every recommendation carries a reason naming the fields, their types, and the aggregation where relevant. No recommendation implies causation.

**Acceptance criterion:** Each returned chart type equals the expected chart type, each refusal carries the expected reason, and no explanation contains causal language.

**Evidence to capture later:** Actual recommend_chart() responses; AI explanation transcript.

**Owner:** Ahmad Essam (expected output) / Youssef Elfeshawy (execution) / Omar Metwally (display)  
**Execution session:** Session 3-4  
**Current status:** Pending execution against the integrated implementation

---
