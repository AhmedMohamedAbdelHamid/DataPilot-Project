# DataPilot — Knowledge, Tools & Quality Module

**Student:** Ahmad Essam · **Team:** Team 07 · **Role:** Knowledge, Tools & Quality Engineer
**Project:** DataPilot — Dataset Analysis & Decision Support Studio
**Version:** profile_version 0.2 · ruleset rules-2026-07-23

This repository contains the complete specification, benchmark fixtures, exact expected
outputs, test plans, documentation templates, handoff materials, and defense preparation for
Ahmad Essam's five-session Knowledge, Tools & Quality Engineer role. Actual backend
verification, UI verification, source approval, security-test execution, screenshots, and final
pass/fail evidence remain pending until team integration.

It contains only the work my role owns: the correctness and trust layer of DataPilot. It does
not contain frontend code, backend implementation, API deployment, or system architecture —
those belong to my teammates.

---

## Read this first: what is done vs. what is pending

This deliverable carefully separates five things:

1. **Specification** — rules and contracts (complete).
2. **Planned test** — a defined test (complete definitions; not executed).
3. **Expected result** — the exact value a test should produce (complete, derived from real data).
4. **Example / mock** — clearly labelled illustrations.
5. **Actual verified evidence** — *none yet.* The integrated implementation has not been run,
   so every actual result reads **"Pending execution against the integrated implementation."**
6. **Approvals** — the 33 design decisions are proposed working rules pending Integration Lead
   approval, and the source register is pending verification. No approval is assumed.

No test is marked passed. No source access date is fabricated. No teammate approval is assumed.

## The one rule everything rests on

> Application code computes every measurable fact. AI may explain, summarize, and suggest next
> steps, but it may never calculate, alter, recompute, or invent numbers.

## Folder guide

| Folder | Contents |
|---|---|
| `Session_1/` | The original Session 1 PDF, a foundation extraction of its fixed decisions, and the 33-decision resolution register |
| `Session_2/` | Final taxonomy; three benchmark datasets with dictionaries, known-issues registers, and exact expected outputs; five core tests; three teammate handoffs |
| `Session_3/` | Source register (pending verification); 10-file bounded knowledge base; traceability model; expected-vs-actual template; backend and chart verification plans |
| `Session_4/` | Ten-case evaluation; injection, formula, and invalid-input tests; AI guardrail evaluation; production documentation; limitations register; release checklist |
| `Session_5/` | Final quality report; defense script; 34-question Q&A; demo checklist; final acceptance matrix |
| `Shared_Checklists/` | Error catalogue, issue cards, severity model, acceptance criteria, backend and UI checklists |

## The benchmark datasets

Three deterministic datasets (seed 20260723), each with documented planted issues:

| Dataset | Shape | Exercises |
|---|---|---|
| `student_performance.csv` | 102 × 12 | Identifiers, missing values, duplicates, range violations, mixed type, boolean, constant column |
| `small_business_sales.csv` | 122 × 13 | Mixed date formats, formula injection, negative values, large values, high-cardinality text |
| `research_survey.csv` | 96 × 12 | Text-stored numbers, all-missing column, out-of-range values, inconsistent tokens, prompt injection |

Every expected profile in `Session_2/expected_outputs/` was **derived from the exact CSV**, not
estimated. Regenerating a dataset with the same seed reproduces it byte-for-byte.

## Four findings worth knowing

Authoring the benchmarks surfaced four limitations that shape the whole module:

1. The IQR rule flags 16 legitimate discount values because the column is discrete.
2. A satisfaction score of 9 (on a 1–5 scale) escapes IQR but is caught by a range check.
3. A single text value ("forty-one") makes the age column text, hiding an extreme value of 91.
4. A multi-format date column is demoted to text, correctly blocking a fabricated trend.

These are documented in `Session_4/known_limitations_register.csv` and demonstrated in
`Session_4/safe_vs_unsafe_ai_examples.md`.

## How to verify my work

- **Reproduce the datasets and expected outputs:** the values in `expected_outputs/` follow the
  proposed working rules (pending Integration Lead approval): D-06, D-08, D-09, D-10, D-11, D-12,
  D-21, D-22, D-24, D-29, D-30. The
  known-issues registers list every planted issue and its expected detection.
- **Check nothing is overclaimed:** search the tree for "Pending execution" — every actual
  result carries it. Search for access dates — every one reads a pending marker.

## Open items for the team

The decisions register and the final acceptance matrix list what still needs the Integration
Lead's approval (the 33 decisions, the candidate sources) and what needs the integrated build
before it can be executed (all verification and evaluation evidence).
