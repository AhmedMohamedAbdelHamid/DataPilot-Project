# Verification Plan — `recommend_chart()`

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Target:** the implemented `recommend_chart()` rule engine
**Status:** plan only. **Pending execution against the integrated implementation.**

---

## 1. Objective

Establish that chart selection follows the deterministic rule table (Session 1 §9.1, carried
unchanged into `chart_rules.json`), and — equally important — that the engine **refuses**
correctly.

A chart engine that always produces a chart is not a rule engine. Most of the risk in this
module is in the refusals: a fabricated timeline from inconsistently parsed dates is worse
than no chart at all.

## 2. What is being verified

| Property | Why it matters |
|---|---|
| Correct chart type for valid inputs | The rule table is the specification |
| Correct refusal for invalid inputs | Prevents misleading visuals |
| A reason accompanies every result | The user must be able to see why |
| Aggregation is stated | "Revenue by region" is ambiguous without it |
| No causal language | A scatter plot shows association only |
| High cardinality suppresses category charts | Prevents unreadable output |
| Identifiers are not grouping fields | Prevents 100-bar charts of student IDs |

## 3. Test matrix

Expected results are in `Session_2/expected_outputs/expected_chart_recommendations.json`
(21 scenarios across the three benchmarks).

### 3.1 Positive cases — a chart should be produced

| ID | Dataset | Request | Expected | Rule |
|---|---|---|---|---|
| RC-01 | student | Exam score by department | `bar_chart`, aggregation = mean | CH-02 |
| RC-02 | student | Distribution of exam scores | `histogram` | CH-03 |
| RC-03 | student | Study hours vs exam score | `scatter_plot` | CH-04 |
| RC-04 | student | Which columns have missing data | `bar_chart` from deterministic counts | CH-05 |
| RC-05 | student | Average attendance | `kpi_card`, aggregation = mean | CH-08 |
| RC-06 | sales | Revenue by region | `bar_chart`, aggregation = sum | CH-02 |
| RC-07 | sales | Category by region | `grouped_bar_chart` | CH-07 |
| RC-08 | sales | Distribution of revenue | `histogram` | CH-03 |
| RC-09 | sales | Share of each payment method | `bar_chart` (not pie) | CH-06 |
| RC-10 | survey | Satisfaction by education level | `bar_chart`, aggregation = mean | CH-02 |
| RC-11 | survey | Distribution of satisfaction | `histogram` | CH-03 |
| RC-12 | survey | Usage frequency distribution | `bar_chart` | CH-06 |

### 3.2 Refusal cases — no chart should be produced

These carry the higher risk and should be executed first.

| ID | Dataset | Request | Expected refusal reason | Rule |
|---|---|---|---|---|
| RC-13 | sales | Revenue by month | `order_date` is text with mixed date formats | CH-01, D-22 |
| RC-14 | survey | Responses over time | `submission_date` is text with mixed date formats | CH-01, D-22 |
| RC-15 | student | Exam score over time | No datetime column exists | CH-01 |
| RC-16 | student | Scores by student ID | Grouping field is an identifier | CH-02 |
| RC-17 | sales | Revenue by note text | `notes` exceeds the high-cardinality threshold | CH-02, D-12 |
| RC-18 | survey | Age vs satisfaction | `age` is text, not numeric | CH-04 |
| RC-19 | survey | Satisfaction by follow-up note | `optional_follow_up` is 100% missing | CH-02 |

RC-13 is the single most important case in this plan. The sales dataset contains genuine
dates in four different formats. A permissive implementation that coerces each value with its
own format will produce a plausible-looking revenue timeline that nobody can reproduce. The
correct behaviour is to refuse and explain.

### 3.3 Guardrail cases — a chart is produced but the language is constrained

| ID | Dataset | Request | Expected |
|---|---|---|---|
| RC-20 | survey | Prove that frequent use causes higher satisfaction | `bar_chart` produced; explanation states association only and declines the causal claim |
| RC-21 | sales | Quantity vs unit price | `scatter_plot` produced; the negative quantity is disclosed as a quality issue |

## 4. Method

```
for each scenario in expected_chart_recommendations.json:
    actual = implemented_recommend_chart(profile, question)
    assert actual.chart_type == expected.recommended_chart
    assert actual.reason is present and non-empty
    if expected.aggregation: assert actual.aggregation == expected.aggregation
    if expected.recommended_chart == "no_chart":
        assert actual.reason names the blocking condition
    assert no causal term appears in actual.reason or the AI explanation
    record(actual, pass_fail, evidence_reference)
```

**Causal-language screen.** The reason text and AI explanation are checked for: *causes,
caused, because of, leads to, results in, drives, impact of, effect of, due to*. A hit is
reviewed manually — "the effect of missing values on the chart" is acceptable; "the effect of
study hours on exam scores" is not.

## 5. Acceptance criteria

| # | Criterion |
|---|---|
| AC-1 | Every positive case returns the expected chart type |
| AC-2 | Every refusal case returns `no_chart` with the expected blocking reason |
| AC-3 | Every result carries a non-empty reason naming the fields and their types |
| AC-4 | Every aggregated chart states its aggregation in the label |
| AC-5 | No result or explanation contains an unjustified causal claim |
| AC-6 | Chart selection is identical across repeated runs for identical inputs |
| AC-7 | No chart is produced from a column with `inferred_type` = identifier or unknown |

## 6. Dependencies

- A completed profile for each fixture (chart rules consume the profile, not the raw CSV).
- The high-cardinality threshold (D-12) approved, since it determines RC-17.
- The date policy (D-22) approved, since it determines RC-13, RC-14 and RC-15.
- Confirmation from the UI engineer that a `no_chart` reason has somewhere to render;
  a refusal that produces an empty panel fails AC-2 in practice even if the API is correct.

## 7. Current state

| Metric | Value |
|---|---|
| Scenarios defined | 21 |
| Positive / refusal / guardrail | 12 / 7 / 2 |
| Scenarios executed | 0 |
| Result | **Pending execution against the integrated implementation** |
