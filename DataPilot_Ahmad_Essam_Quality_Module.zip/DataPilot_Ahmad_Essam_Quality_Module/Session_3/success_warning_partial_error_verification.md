# Verification — Success, Warning, Partial and Error Behaviour

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Status:** specification and plan. **Pending execution against the integrated implementation.**

---

## 1. The four statuses

| Status | Meaning | Numbers returned? | `error` populated? |
|---|---|---|---|
| `success` | Profiling completed with no irregularities | All | No |
| `success_with_warnings` | Completed, but recoverable irregularities found | All | No |
| `partial` | Some columns profiled, others could not be | Only for profiled columns | No |
| `error` | Profiling could not proceed | **None** | Yes |

The rule that binds all four: **a status never implies more completeness than actually exists,
and no status permits a fabricated number.**

## 2. `success`

**Conditions:** parse succeeded; every column typed and summarised; `warnings` empty.

**Required output:** every contracted field populated; `warnings` an empty array; `error` null.

**Note:** none of the three benchmark datasets returns `success`. They were designed to
contain issues, so all three return `success_with_warnings`. A clean-dataset fixture for the
pure `success` path is a **gap in the current benchmark set** and is recorded as a Session 4
follow-up (see `known_limitations_register.csv`, KL-14).

**Verification:** submit a small clean CSV; confirm `status = success`, `warnings = []`,
`error = null`.

## 3. `success_with_warnings`

**Conditions:** profiling completed, but at least one recoverable irregularity was found:
constant column, high cardinality, mixed type, mixed date formats, inconsistent category
spelling, formula-like content, all-missing column, identifier suppression, encoding
fallback, or recovered ragged rows.

**Required output:** full results, plus every irregularity present in `warnings` or in the
relevant column's `warnings` array. Warnings are structured, not free prose.

**Expected warnings per benchmark**

| Dataset | Count | Codes |
|---|---|---|
| `student_performance` | 5 | `identifier_not_summarized`, `inconsistent_category_spelling` ×2, `mixed_type`, `constant_column` |
| `small_business_sales` | 8 | `identifier_not_summarized`, `mixed_date_formats`, `inconsistent_category_spelling` ×2, `constant_column`, `high_cardinality` ×2, `formula_like_content` |
| `research_survey` | 12 | `identifier_not_summarized`, `mixed_date_formats`, `mixed_type`, `inconsistent_category_spelling` ×5, `high_cardinality`, `constant_column`, `all_missing` |

**Verification:** confirm the status, confirm every expected warning code is present, and
confirm results are still complete. A warning must never reduce what is reported.

## 4. `partial`

**Conditions:** at least one column profiled successfully and at least one could not be.

**Required output:**
- Profiled columns returned normally.
- Unprofiled columns present in `column_profiles` with a clear warning, `inferred_type`
  unknown, and **no invented values** — nulls, not zeros.
- The output states which columns were skipped and why.
- Dataset-level counts (`rows`, `columns`) still reported, since they are known.

**Example shape:**

```json
{
  "status": "partial",
  "rows": 500,
  "columns": 9,
  "column_profiles": [
    { "name": "revenue", "inferred_type": "numeric", "numeric_summary": { "...": "..." } },
    { "name": "raw_blob", "inferred_type": "unknown", "numeric_summary": null,
      "warnings": [{ "code": "column_skipped", "severity": "medium",
                     "message": "This column could not be read and was not analysed." }] }
  ],
  "warnings": [{ "code": "partial_profile", "severity": "medium",
                 "message": "1 of 9 columns could not be analysed: raw_blob." }],
  "error": null
}
```

**Open dependency:** whether `partial` will be implemented in the pilot at all is a question
for the backend engineer (listed in the backend handoff). If it is not implemented, edge
cases E-42, E-21 and E-24 need a different expected behaviour, and this section becomes a
Session 5 future-work item rather than a verification target.

**Distinguishing `partial` from `success_with_warnings`:** a warning means "this was analysed,
but note something". `partial` means "this was not analysed at all". Conflating them would
let a user believe a column was checked when it was not.

## 5. `error`

**Conditions:** profiling cannot proceed — empty dataset, malformed CSV, limit exceeded,
timeout, internal failure.

**Required output:**
- `status = "error"`.
- `error.code` from the fixed catalogue; `error.message` the canonical safe message.
- `rows` and `columns` **null**, not zero. Zero is a measurement; null is an absence.
- No `column_profiles`, no statistics, no partial numbers.
- `retry_allowed` set per `error_messages.json`.
- No stack trace, internal path, provider name, or secret.

**Verification matrix**

| Input | Expected code | Retry | Numbers returned |
|---|---|---|---|
| Zero-byte file | `EMPTY_DATASET` | Yes | None |
| Header-only file | `EMPTY_DATASET` | Yes | None |
| `.xlsx` renamed `.csv` | `INVALID_FILE_TYPE` | Yes | None |
| 15 MB file | `LIMIT_EXCEEDED` | Yes | None |
| Broken quoting | `MALFORMED_CSV` | Yes | None |
| Undecodable encoding | `MALFORMED_CSV` | Yes | None |
| Processing exceeds limit | `TOOL_TIMEOUT` | Yes | None |
| Uncaught exception | `PROFILE_FAILED` | Yes | None |

## 6. The escalation rule

If the tool fails and the user asks for an estimate anyway, the answer is no. Rule NF-11:

> "Profiling did not complete, so no figures can be reported. Please correct the file and try
> again."

This is the point at which the deterministic principle is most likely to bend in practice,
because refusing is less satisfying than answering. It must not bend. A fabricated figure
delivered confidently after a failure is the worst output DataPilot could produce.

## 7. Cross-status invariants

| # | Invariant | Applies to |
|---|---|---|
| INV-1 | No fabricated or estimated number in any status | All |
| INV-2 | `profile_version`, `ruleset_version`, `run_id` present in every response | All |
| INV-3 | No stack trace, secret, or internal path in any response | All |
| INV-4 | Row and column counts null on error, never zero | `error` |
| INV-5 | Warnings never reduce the completeness of results | `success_with_warnings` |
| INV-6 | Skipped columns are named, never silently omitted | `partial` |
| INV-7 | Every code maps to exactly one canonical message | `error` |

## 8. Current state

| Status | Checks defined | Executed | Result |
|---|---|---|---|
| `success` | 3 | 0 | Pending execution — **fixture gap noted** |
| `success_with_warnings` | 28 | 0 | Pending execution |
| `partial` | 6 | 0 | Pending execution — implementation undecided |
| `error` | 8 | 0 | Pending execution |
| Invariants | 7 | 0 | Pending execution |
