# Traceability Display Requirements

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Audience:** Omar Metwally (UI), Youssef Elfeshawy (backend fields)
**Status:** specification. Verification against the built interface is
**Pending execution against the integrated implementation.**

---

## 1. The requirement in one sentence

A user must always be able to answer the question *"where did this come from?"* for anything
DataPilot puts on screen — and the answer must be different for a measured number than for a
sentence of explanation.

## 2. Five display kinds

Every element on screen belongs to exactly one of these. They must be visually distinguishable.

| Kind | What it is | Traceability shown | Example |
|---|---|---|---|
| **Deterministic evidence** | A number computed by `profile_dataset()` | Tool, version, ruleset, run ID, calculation method | "4 missing values (3.92% of 102 rows)" |
| **AI explanation** | Plain-language prose about the evidence | Label only; derives from the profile, has no independent authority | "A few exam scores are missing, which you may want to consider." |
| **General guidance** | A definition or method explanation | Source ID, title, approval status, scope limitation | "The IQR method screens for values worth investigating." |
| **Recommendation** | Output of `recommend_chart()` | Rule ID, input fields and types, aggregation | "Bar chart — department (categorical) × exam_score (numeric), mean" |
| **Limitation** | A bound on what may be claimed | Limitation ID | "Potential outliers are flagged, not confirmed as errors." |

## 3. Non-negotiable display rules

1. **Evidence and explanation never share a visual treatment.** If a user cannot tell at a
   glance which is which, the requirement is not met.
2. **The AI explanation carries a persistent label**, for example
   *"AI explanation — based on the profile above"*. The label must remain visible when the
   text is scrolled or collapsed.
3. **A candidate source must be visibly marked as not approved.** Showing "NIST guidance"
   without "Candidate — pending approval" misrepresents the evidence base.
4. **A dataset-specific number is never attributed to a source.** There is no interface path
   where a citation appears next to a computed statistic. This is the single most important
   rule in this document.
5. **Every chart states its aggregation** in the axis label, not only in a tooltip.
6. **Limitations appear with results**, not behind a link or in a footer.

## 4. Required fields per kind

### Deterministic evidence
```
dataset_id, dataset_version, tool_name, tool_version, rule_version,
run_id, calculated_field, calculation_method
```
A compact treatment satisfies this — an information affordance revealing:

> Measured by `profile_dataset` v0.2 · ruleset `rules-2026-07-23` · run `run-20260723-101500-A1B2`
> · rule: count of cells matching the missing-token set · denominator: 102 total rows

### General guidance
```
source_id, source_title, organization, supported_claim, scope_limitation, approval_status, access_date
```
Where the access date is not yet recorded, display the pending marker verbatim rather than
omitting the field or showing a blank.

### Recommendation
```
rule_id, input_fields, input_types, aggregation, guardrail
```

## 5. Worked screen examples

### 5.1 Correct

> **Missing values — exam_score**  ·  Review
> **4** of 102 rows (**3.92%**) have no value.
> ⓘ Measured by profile_dataset v0.2 · rule: D-08 missing-token match · denominator: 102 rows
>
> ---
> *AI explanation — based on the profile above*
> A small number of exam scores are missing. Consider this before comparing departments,
> since the comparison uses only the rows that have a score.

Evidence and explanation are separated, the number appears in the evidence block, and the
explanation introduces no new figure.

### 5.2 Incorrect

> **Missing values**
> About 4% of exam scores are missing (roughly 4 students), which is a normal amount and
> shouldn't affect your results.

Four failures: the percentage is approximated rather than quoted; "roughly 4 students"
introduces an interpretation of rows as people; "a normal amount" is an unsupported judgement;
"shouldn't affect your results" contradicts guardrail IG-03, which requires stating that the
exact impact cannot be assumed.

### 5.3 Correct — a refusal

> **No chart available**
> A trend chart needs a date column. `order_date` uses more than one date format
> (`2025-03-14`, `14/03/2025`, `March 5, 2025`), so it is being read as text.
> ⓘ Rule CH-01 · guardrail: date parsing must be reliable
>
> Available alternatives: compare revenue by `region`, or view the distribution of `revenue`.

The refusal explains itself, names the rule, and offers a route forward. An empty panel would
fail this requirement.

### 5.4 Incorrect — attribution error

> The standard deviation is 19.03 *(source: pandas documentation)*.

This violates rule TR-03. pandas documents how a standard deviation is *defined*; it did not
compute this dataset's value. The correct form:

> The standard deviation is 19.03, computed by `profile_dataset` v0.2 using the sample (N−1)
> convention.

## 6. Sensitive and injected content

- Sample values are capped at 3 per column and 60 characters each (D-15, D-26).
- Values beginning `=`, `+`, `-`, `@` display with a leading apostrophe and are never
  evaluated, including on export (D-25).
- `<` and `>` are escaped; no cell content is ever rendered as HTML.
- The survey benchmark's `comments` column contains planted injection strings. They must
  render as inert, visibly-quoted sample text, clearly inside the evidence block as *data*,
  never in a position that could read as system output.

## 7. Verification method

Checks are recorded in `Shared_Checklists/ui_quality_checklist.csv`. The two decisive ones:

- **TRACE-1:** every number visible on screen appears in the backend JSON for that run.
- **TRACE-2:** no sentence in the AI explanation contains a number absent from that JSON.

Both are currently **Pending execution against the integrated implementation.**
