# Verification Plan — `profile_dataset()`

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Target:** the implemented `profile_dataset()` owned by the AI & Backend Engineer
**Status:** plan only. **Pending execution against the integrated implementation.**

---

## 1. Objective

Establish, with recorded evidence, that the implemented `profile_dataset()` produces exactly
the values specified in the Session 2 expected profiles for three known datasets, and behaves
correctly on inputs designed to break it.

Correctness here is not "the output looks reasonable". It is "every field equals the expected
value, and any difference is explained".

## 2. What makes this verifiable

The expected outputs were derived from the exact benchmark CSVs under the proposed working rules (pending Integration Lead approval), not
estimated. That means a difference between expected and actual is always one of exactly three
things:

1. The implementation applies a rule differently from the specification.
2. The specification is ambiguous and both readings are defensible.
3. My expected value is wrong.

All three are useful findings. The third is the reason the derivation script and the expected
values are both included in this deliverable — so my own work can be checked, not just the
backend's.

## 3. Method

```
for each fixture in {student_performance, small_business_sales, research_survey}:
    actual   = implemented_profile_dataset(fixture)
    expected = load(fixture + "_expected_profile.json")
    for each check in expected_vs_actual_template.csv:
        compare(actual[path], expected[path], rule, tolerance)
        record(actual_value, pass_fail, evidence_reference)
```

**Comparison rules**

| Value type | Rule | Tolerance |
|---|---|---|
| Integer counts | Exact equality | 0 |
| Percentages | Numeric equality | 0.01 |
| Numeric summaries | Numeric equality | 1e-6 (D-31) |
| Strings and enums | Exact equality | — |
| Warning presence | Code present in list | — |
| Ordered arrays | Set comparison unless order is specified | — |

**Evidence captured per run:** the actual JSON, the completed comparison row, the `run_id`,
and the tool and ruleset versions.

## 4. Phased execution

### Phase 1 — Shape and metadata (12 checks)
Row counts, column counts, status, `profile_version`, `ruleset_version`, `run_id` format,
`processing_metadata.tool`. If Phase 1 fails, later phases are not meaningful.

### Phase 2 — Type inference (13 checks)
The highest-risk phase. Every downstream statistic depends on the type being right.

Priority order:
1. `student_id`, `order_id`, `response_id` → identifier (blocks the "average ID" failure).
2. `assignment_score`, `age` → text via mixed-type (blocks silent coercion).
3. `order_date`, `submission_date` → text via mixed date formats (blocks fabricated trends).
4. `optional_follow_up` → unknown (blocks statistics over nothing).
5. `scholarship_status` → boolean; `consent_given` and `recommend_service` → **not** boolean.

### Phase 3 — Counts (16 checks)
Missing counts and percentages, duplicate counts and percentages, unique counts. Confirm the
denominator is total rows in every percentage.

### Phase 4 — Statistics (12 checks)
Mean, median, min, max, Q1, Q3, std for every numeric column. Confirm `std_convention` and
`percentile_method` are emitted.

**Deliberate divergence test:** compute `exam_score` Q1 under nearest-rank instead of linear
interpolation. If the implementation returns the nearest-rank value, D-21 has not been
applied. This is a targeted check, not a general comparison.

### Phase 5 — Anomalies (8 checks)
The two diagnostic cases:

| Case | Expected | What a wrong answer means |
|---|---|---|
| `discount_percentage` flags 16 values | 16 | A different count means the fences are computed differently |
| `satisfaction_score` value 9 **not** flagged | absent from anomalies | Flagging it means Q3 or the fence is wrong |

### Phase 6 — Issues and severity (8 checks)
Every issue card carries type, severity, and evidence; severity matches the D-29 thresholds.

### Phase 7 — Failure paths (10 checks)
Empty file, header-only, oversized, wrong type, ragged rows, broken quoting, unknown encoding.
Confirm no fabricated numbers appear on any failure path.

### Phase 8 — Security (8 checks)
Injection payloads leave counts unchanged; formula-leading values neutralized; samples capped
and escaped; nothing sensitive in logs or responses.

### Phase 9 — Reproducibility (6 checks)
Run each fixture three times; outputs must be byte-identical apart from `run_id` and any
timestamp.

## 5. Failure handling

| Outcome | Action |
|---|---|
| Actual = expected | Record Pass with the evidence reference |
| Actual ≠ expected, implementation wrong | Raise with the backend engineer; record Fail; retest after fix |
| Actual ≠ expected, my expected value wrong | Correct the expected profile, document the correction, regenerate; record as a specification defect against myself |
| Actual ≠ expected, specification ambiguous | Escalate to the Integration Lead as a decision; record Partial until resolved |
| Cannot execute | Record **Pending execution**; never Pass |

The third row is deliberate. If my expected value is wrong, that is my defect and it is
recorded as mine.

## 6. Entry and exit criteria

**Entry:** `profile_dataset()` is callable against a fixture; decisions D-01 … D-33 approved
or at least confirmed as working defaults; the expected profiles are fixed for authoring consistency (pending approval of the underlying decisions).

**Exit:** all 76 backend checks and all 73 comparison rows carry a recorded actual value and
a Pass, Fail, or Partial result; every Fail has an owner and a retest date; the summary is
recorded in `Session_4/session4_quality_report.md`.

## 7. Current state

| Metric | Value |
|---|---|
| Checks defined | 76 |
| Comparison rows defined | 73 |
| Checks executed | 0 |
| Result | **Pending execution against the integrated implementation** |
