# Backend Verification Checklist

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Verifies:** the implementation built by Youssef Elfeshawy (AI & Backend Engineer)
**Status:** every item below is **Pending execution against the integrated implementation.**

This checklist verifies behaviour against the specification. It does not review code style,
architecture, or deployment, which belong to other roles.

---

## How verification works

1. Submit a benchmark fixture to the implemented `profile_dataset()`.
2. Capture the actual JSON output.
3. Compare field by field against the corresponding `*_expected_profile.json`.
4. Record each result in `expected_vs_actual_template.csv` (73 checks defined).
5. A check passes only when the actual value equals the expected value within tolerance
   **1e-6** for floats (D-31) and exactly for strings, integers, and enums.

A check with no recorded actual value is **"Not yet assessed"**, never "Pass".

---

## A. Parsing and limits

| # | Check | Expected | Status |
|---|---|---|---|
| A1 | File over 10 MB rejected | `LIMIT_EXCEEDED`, limit stated in message | Pending |
| A2 | Row count over 100,000 rejected | `LIMIT_EXCEEDED` | Pending |
| A3 | Column count over 100 rejected | `LIMIT_EXCEEDED` | Pending |
| A4 | Non-CSV file rejected | `INVALID_FILE_TYPE` | Pending |
| A5 | Zero-byte file | `EMPTY_DATASET` | Pending |
| A6 | Header-only file | `EMPTY_DATASET`, header acknowledged | Pending |
| A7 | Encoding detected, fallback warned not hidden | `encoding_fallback` warning | Pending |
| A8 | Delimiter mismatch produces a warning, never a silent re-parse | Warning surfaced | Pending |
| A9 | Ragged rows never silently padded | Warning or `MALFORMED_CSV` | Pending |
| A10 | Broken quoting reports the offending row | `MALFORMED_CSV` with row number | Pending |

## B. Shape and counts

| # | Check | Expected | Status |
|---|---|---|---|
| B1 | `rows` excludes the header | 102 / 122 / 96 | Pending |
| B2 | `columns` equals header field count | 12 / 13 / 12 | Pending |
| B3 | Missing counts per column | See expected profiles | Pending |
| B4 | Missing percentage denominator is total rows | e.g. exam_score 3.92% of 102 | Pending |
| B5 | Duplicate count by full-row match | 2 / 2 / 1 | Pending |
| B6 | Duplicate percentage | 1.96 / 1.64 / 1.04 | Pending |
| B7 | Unique count excludes missing values | e.g. student_id 100 | Pending |
| B8 | Row count unchanged after duplicate detection | 102 / 122 / 96 | Pending |

## C. Type inference

| # | Check | Expected | Status |
|---|---|---|---|
| C1 | `student_id` → identifier, `numeric_summary` null | identifier | Pending |
| C2 | `order_id` → identifier | identifier | Pending |
| C3 | `response_id` (text code) → identifier | identifier | Pending |
| C4 | `scholarship_status` → boolean | boolean | Pending |
| C5 | `consent_given` (single value) → **not** boolean | categorical + constant warning | Pending |
| C6 | `recommend_service` (5 tokens) → **not** boolean | categorical | Pending |
| C7 | `assignment_score` (contains "absent") → text | text + `mixed_type` | Pending |
| C8 | `age` in survey (contains "forty-one") → text | text + `mixed_type` | Pending |
| C9 | `order_date` (4 formats) → text | text + `mixed_date_formats` | Pending |
| C10 | `submission_date` (3 formats) → text | text + `mixed_date_formats` | Pending |
| C11 | `optional_follow_up` (all missing) → unknown | unknown + `all_missing` | Pending |
| C12 | `notes` (75 distinct / 122 rows) → text | text + `high_cardinality` | Pending |
| C13 | `academic_year` / `status` → constant warning | `constant_column` | Pending |

C1 and C7 are the two most consequential checks in this section. C1 is what stops a student
ID being averaged; C7 is what stops a single text cell being silently coerced to a number.

## D. Statistics

| # | Check | Expected | Status |
|---|---|---|---|
| D1 | `age` mean | 20.2843 | Pending |
| D2 | `age` std (sample, N−1) | 1.3525 | Pending |
| D3 | `exam_score` median | 65.5 | Pending |
| D4 | `exam_score` q1 / q3 (linear interpolation) | 48.0 / 84.0 | Pending |
| D5 | `revenue` median | 899.0 | Pending |
| D6 | `revenue` max | 58000.0 | Pending |
| D7 | `quantity` min (negative present) | −2.0 | Pending |
| D8 | `satisfaction_score` mean | 3.2609 | Pending |
| D9 | Missing values excluded from all numeric calculations | count 98 for exam_score, not 102 | Pending |
| D10 | `std_convention` emitted in output | "sample (N-1)" | Pending |
| D11 | `percentile_method` emitted in output | "linear" | Pending |
| D12 | No numeric summary for any identifier column | null | Pending |

D10 and D11 are not optional decoration. Without them a reviewer cannot reproduce the
numbers, and reproducibility is the entire argument for the deterministic layer.

## E. Anomalies

| # | Check | Expected | Status |
|---|---|---|---|
| E1 | `study_hours_per_week` potential outliers | 2 (values 45, 48) | Pending |
| E2 | `study_hours_per_week` fences | [−2.125, 24.875] | Pending |
| E3 | `revenue` potential outliers | 9 | Pending |
| E4 | `discount_percentage` potential outliers | **16** — correct for discrete data | Pending |
| E5 | `satisfaction_score` — value 9 **not** flagged by IQR | absent from anomalies | Pending |
| E6 | Method name recorded with every flag | "IQR-1.5" | Pending |
| E7 | Columns with < 4 non-missing values not screened | no anomalies block | Pending |
| E8 | No output word implies a flagged value is an error | non-committal wording | Pending |

If E4 returns a number other than 16, the implementation is not applying the IQR rule as
specified. If E5 flags the value 9, the quartile calculation is wrong.

## F. Quality issues and severity

| # | Check | Expected | Status |
|---|---|---|---|
| F1 | Missing-value severity by D-29 thresholds | low / medium / high correctly assigned | Pending |
| F2 | `optional_follow_up` at 100% missing → high | high | Pending |
| F3 | Duplicate severity above 1% → medium | medium | Pending |
| F4 | Out-of-range issue for `attendance_percentage` 104.5 | present, medium | Pending |
| F5 | Out-of-range issue for `satisfaction_score` 9 | present, medium | Pending |
| F6 | Negative-value issue for `quantity` | present, medium | Pending |
| F7 | Every issue card carries type, severity, and evidence | all fields present | Pending |
| F8 | Severity never assigned by the AI | deterministic only | Pending |

## G. Statuses and errors

| # | Check | Expected | Status |
|---|---|---|---|
| G1 | All three benchmarks return `success_with_warnings` | correct status | Pending |
| G2 | `error` is null on success | null | Pending |
| G3 | Failure path returns no fabricated numbers | rows/columns null | Pending |
| G4 | Each error code carries its canonical message | matches `error_messages.json` | Pending |
| G5 | No stack trace, internal path, or provider name in any response | absent | Pending |
| G6 | `partial` status names skipped columns and reasons | present if implemented | Pending |

## H. Security

| # | Check | Expected | Status |
|---|---|---|---|
| H1 | Injection payloads in `comments` do not alter any count | `satisfaction_score.missing_count` = 4 | Pending |
| H2 | Formula-leading values neutralized in `sample_values` | apostrophe-prefixed | Pending |
| H3 | Angle brackets escaped in samples | escaped | Pending |
| H4 | Sample values capped at 3 per column | ≤ 3 | Pending |
| H5 | Sample values capped at 60 characters | ≤ 60 with ellipsis | Pending |
| H6 | AI context capped at 8,000 characters | enforced | Pending |
| H7 | Raw cell values absent from logs | absent | Pending |
| H8 | No secret or environment variable in any response | absent | Pending |

## I. Reproducibility and traceability

| # | Check | Expected | Status |
|---|---|---|---|
| I1 | Same input produces byte-identical output across runs | identical | Pending |
| I2 | `profile_version` present | "0.2" | Pending |
| I3 | `ruleset_version` present | "rules-2026-07-23" | Pending |
| I4 | `run_id` format | `run-YYYYMMDD-HHMMSS-XXXX` | Pending |
| I5 | `processing_metadata.tool` | "profile_dataset" | Pending |
| I6 | No dataset value attributed to an external source | none | Pending |

## J. Chart recommendation

| # | Check | Expected | Status |
|---|---|---|---|
| J1 | Trend request on `order_date` refused | `no_chart` + date reason | Pending |
| J2 | Category comparison on `department` | `bar_chart`, aggregation stated | Pending |
| J3 | Grouping by an identifier refused | `no_chart` | Pending |
| J4 | Grouping by `notes` (high cardinality) refused | `no_chart` | Pending |
| J5 | Scatter on `age` (text) refused | `no_chart` + mixed-type reason | Pending |
| J6 | All-missing column cannot group | `no_chart` | Pending |
| J7 | Every recommendation carries a reason | present | Pending |
| J8 | No recommendation implies causation | absent | Pending |

## K. AI boundary

| # | Check | Expected | Status |
|---|---|---|---|
| K1 | No number in the AI response is absent from the profile | none | Pending |
| K2 | No column mentioned that is absent from `column_profiles` | none | Pending |
| K3 | No causal claim | absent | Pending |
| K4 | Potential outliers never called errors | correct wording | Pending |
| K5 | No claim that data was cleaned, filled, or de-duplicated | absent | Pending |
| K6 | Cell instructions never followed | ignored | Pending |
| K7 | Profile still renders when the AI layer fails | evidence independent of AI | Pending |

---

## Summary

**Total checks: 76.** Passed: 0. Failed: 0. **Not yet assessed: 76.**

No check may be marked Pass without a captured actual output recorded in
`expected_vs_actual_template.csv`.
