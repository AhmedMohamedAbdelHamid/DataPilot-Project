# Source Verification Report — Session 3

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Register:** `verified_source_register.csv` (11 entries)
**Overall verification status:** **Verification pending — access dates not recorded**

---

## 1. Honest statement of what this report is

This report records the *state* of source verification, not a claim that verification has
been completed. No source in the register has been independently opened and content-checked
as part of this deliverable, so **no access date has been recorded for any entry**. Every
`access_date` field reads either `[To be verified]` (carried from Session 1) or
`Verification pending — access date not recorded`.

Fabricating an access date would be the single easiest way to make this register look
finished and the single most damaging thing I could do to its credibility. The dates stay
empty until the sources are actually opened.

## 2. Register composition

| Category | Count | IDs |
|---|---|---|
| Approved (handbook starting resources) | 3 | S-01, S-02, S-03 |
| Candidate — pending team-lead approval | 8 | C-04 … C-11 |
| **Total** | **11** | |

**No candidate is presented as approved anywhere in this deliverable.** The three approved
entries are approved because the course handbook lists them as starting resources for Team
07, not because their content has been verified.

## 3. Source tiering

Sources are preferred in the order fixed in Session 1 §5.2.

| Tier | Type | Entries |
|---|---|---|
| 1 | Official documentation | S-01, S-02, S-03, C-04 |
| 2 | Standards organizations | C-07 (IETF), C-08 (NIST), C-10 (ISO/IEC) |
| 3 | Security organizations | C-05, C-06, C-11 (all OWASP) |
| 4 | Primary academic sources | none currently |
| 5 | Established technical documentation | C-09 |

C-09 (consumer search guidance) is the weakest entry and backs only review criteria that are
already written into the Session 1 lifecycle. If the Integration Lead prefers a leaner
register, C-09 is the first candidate to drop.

## 4. What each source is allowed to support

The scope limitation matters as much as the claim. The recurring failure mode in a project
like this is citing a library manual as though it produced a number.

| ID | Backs | Explicitly does **not** back |
|---|---|---|
| S-01 | How CSV parsing is configured | Any dataset-specific statistic |
| S-02 | Reproducible loading and inspection patterns | Statistical definitions |
| S-03 | Which chart types can be rendered | Which chart is *appropriate* for a question |
| C-04 | Definitions of count, mean, std, quantiles and their conventions | The team's choice to adopt them |
| C-05 | Prompt injection as a recognised risk class | That DataPilot's defences are sufficient |
| C-06 | Spreadsheet formula-injection risk | The specific neutralization method chosen |
| C-07 | Baseline well-formed CSV structure | That deviation proves corruption |
| C-08 | IQR as a screening method **and its limitations** | Treating flagged values as errors |
| C-09 | General source-assessment criteria | Any technical claim |
| C-10 | Data-quality vocabulary | Any detection method |
| C-11 | Escaping untrusted content before rendering | That DataPilot's rendering is safe |

C-08's scope limitation is doing real work here. The Session 2 benchmarks produced two
findings that the NIST guidance would predict and that no citation could excuse:

- `discount_percentage` flags **16** potential outliers purely because the values are
  discrete (0, 5, 10, 15). Q3 is 5, so the upper fence sits at 12.5 and every 15% discount is
  caught.
- `satisfaction_score` contains the value **9**, outside its documented 1–5 range, yet the
  IQR upper fence is 9.5, so **IQR does not flag it at all**.

Neither is a bug. Both are evidence that a single anomaly method is insufficient, which is
exactly what the source's scope limitation says.

## 5. Verification procedure to be executed

For each source, in the lifecycle order fixed in Session 1 §5.3:

1. **Identify** — done for all 11 entries.
2. **Verify** — open the URL, confirm the organization and authorship, confirm the claim in
   the register is actually supported by the content, note the publication or last-updated
   date. *Not yet performed.*
3. **Record** — write the real access date and the version/update date. *Blocked on step 2.*
4. **Review** — compare against any higher-tier alternative; record rejections with reasons.
5. **Approve** — Integration Lead signs off each candidate for a specific documented use.
6. **Use** — the source may back claims only within its recorded scope.
7. **Recheck** — at each session gate (D-28).

## 6. Rejection criteria

A source is rejected if authorship or organization is unclear; if the claim cannot be
independently corroborated; if it is outdated in a way that affects the claim; or if it
conflicts with a higher-tier source. Rejections are recorded in the register's review notes
rather than deleted, so the reasoning survives.

No source has been rejected yet, because no source has been verified yet.

## 7. Risks in the current state

| Risk | Impact | Mitigation |
|---|---|---|
| A candidate is used before approval | A product claim rests on an unapproved source | Candidates are excluded from `approved_sources.json`'s `approved` array |
| A source changes after being cited | A recorded claim no longer matches the source | Recheck at each session gate (D-28) |
| The register is read as verified | Overstates the evidence base | This report and every access-date field state the pending status explicitly |
| Over-reliance on C-08 for the anomaly method | The method's limits get lost | The limits are written into `limitations.json` (LIM-19, LIM-20) and demonstrated in the benchmarks |

## 8. Blocking dependency

Steps 2–5 above require the Integration Lead's approval decisions. Until then:

- The three approved sources may back claims within their recorded scope.
- The eight candidates may be referenced as *proposed* support only, always with their
  status visible.
- Every access date remains **Verification pending — access date not recorded**.
