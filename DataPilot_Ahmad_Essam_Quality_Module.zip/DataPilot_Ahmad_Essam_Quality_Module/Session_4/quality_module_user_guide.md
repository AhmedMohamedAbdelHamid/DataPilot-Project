# DataPilot Quality Module — User Guide

**For:** analysts, reviewers, and teammates who consume the quality module's outputs.
**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07

This guide explains how to read what DataPilot tells you. It does not cover installation or
the interface build, which belong to other roles.

---

## What DataPilot does

You upload a CSV. DataPilot measures it with application code, explains those measurements in
plain language, suggests a chart, and lets you export the result. Every number you see is
measured, not guessed.

## Reading a profile

**Shape.** Row and column counts. Rows never include the header.

**Column types.** Each column is given a detected type: number, category, date, text, boolean,
ID, or unknown. "Detected" is deliberate — it is a careful inference, not a guarantee. An ID
column (like a student or order number) is never averaged, because an average ID is meaningless.

**Missing values.** Counted per column, with the percentage always out of the total number of
rows. DataPilot never fills a gap for you.

**Duplicate rows.** Rows identical across every column. DataPilot reports them and never
removes them without you.

**Potential outliers.** Numbers far from the middle of a column, flagged by the IQR rule. The
word "potential" is important: a flagged value may be perfectly real. DataPilot will never call
it an error or delete it.

**Quality issues.** Concrete, evidenced problems — missing values, duplicates, out-of-range
values, and so on — each rated Minor, Review, or Important by a fixed rule.

## Things worth understanding

**A flag is not a verdict.** In one of our test datasets, every 15% discount gets flagged as a
potential outlier. That is not because the discounts are wrong; it is because the outlier
method does not fit a column that only holds a few values. DataPilot will tell you when this
happens.

**Out of range is not the same as outlier.** A satisfaction score of 9 on a 1–5 scale is
clearly wrong, but it can still sit inside the statistical fences and escape the outlier check.
DataPilot uses a separate range check to catch exactly this, and will show it as a quality
issue.

**A type problem can hide a value problem.** If one age is written "forty-one", the whole age
column becomes text, and no statistics — including outlier checks — run on it. Fix the text
value and the column can be analysed as numbers.

**Dates need one format.** If a date column mixes formats, DataPilot treats it as text and will
not draw a timeline, because a timeline built from misread dates would be fiction.

## Reading the explanation

The AI explanation is labelled and kept separate from the measured numbers. It can describe,
summarise, and suggest next steps. It cannot calculate, change a number, invent a column, or
claim that one thing caused another. If you ever see a number in the explanation that is not in
the measured profile, that is a bug — report it.

## Charts

DataPilot suggests a chart from a fixed set of rules and always tells you why. When it declines
to draw a chart, it explains what was missing rather than showing an empty box. A chart shows
that things move together; it never proves that one causes the other.

## What DataPilot will not do

It will not clean your data, fill blanks, remove duplicates, run formulas from your cells, make
medical, legal, financial, or employment decisions, or process files that are not CSV or that
exceed the size limits. These limits are shown with your results, not hidden.

## If something goes wrong

DataPilot returns a plain message and, where sensible, invites you to retry. It never shows you
a technical stack trace, and it never invents a figure to cover a failure. If profiling cannot
complete, it will say so rather than estimate.
