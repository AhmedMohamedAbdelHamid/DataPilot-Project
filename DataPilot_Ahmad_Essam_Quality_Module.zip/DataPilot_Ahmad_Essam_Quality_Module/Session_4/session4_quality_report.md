# Session 4 Quality Report

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Version:** profile_version 0.2 · ruleset rules-2026-07-23
**Reporting status:** this report summarises what has been *specified and prepared*. It does
not report test outcomes, because no test has been executed against an integrated
implementation. Every evaluation result is **Pending execution**.

---

## 1. What Session 4 prepared

| Artefact | Count | File |
|---|---|---|
| Ten-case evaluation | 10 cases | `ten_case_evaluation.csv` / `.md` / `.json` |
| Prompt-injection tests | 12 attacks | `prompt_injection_tests.csv` |
| Formula-injection tests | 10 cases | `formula_injection_tests.csv` |
| Invalid-input tests | 23 cases | `invalid_input_tests.csv` |
| AI guardrail checks | 15 checks | `ai_guardrail_evaluation.csv` |
| Safe/unsafe AI examples | 12 pairs | `safe_vs_unsafe_ai_examples.md` |
| Production documentation | 26 sections | `production_documentation.md` |
| Known limitations | 22 items | `known_limitations_register.csv` |
| Release gates | 14 gates | `release_quality_checklist.csv` |

## 2. Evaluation composition

The ten-case matrix covers the required spread: 5 normal, 2 not-found, 1 malformed, 2
injection. Each case names its fixture, exact input, expected deterministic output, expected AI
behaviour, expected UI behaviour, and the evidence to be captured. None is marked passed.

## 3. Findings from authoring (not from execution)

Building the benchmarks and expected outputs surfaced four substantive findings. These are
design findings, established by deriving expected values from real data — not test results.

1. **The IQR method over-flags discrete columns.** `discount_percentage` holds only 0, 5, 10,
   15. Q3 is 5 and the upper fence is 12.5, so all sixteen 15% discounts are flagged. This is a
   documented method limitation (KL-15), not a data fault, and the product must explain it
   rather than present it as poor data quality.

2. **Range and outlier checks are not interchangeable.** `satisfaction_score` contains a 9 on a
   1–5 scale. The IQR upper fence is 9.5, so IQR does not flag it. Only the documented-range
   check catches it (KL-16). This is the strongest single argument for not relying on one
   anomaly method.

3. **A type problem can mask a value problem.** One age written "forty-one" makes the whole age
   column text, so the extreme value 91 is never evaluated (KL-17).

4. **Multi-format dates block trends by design.** The sales `order_date` mixes four formats and
   is demoted to text, correctly preventing a fabricated timeline (KL-18).

Each finding is now a limitation in the register and a worked example in the safe/unsafe AI
reference.

## 4. Coverage against the edge-case register

The Session 1 register has 42 edge cases. Session 4 test coverage:

| Category | Edge cases | Covered by a Session 4 test |
|---|---|---|
| File-level | E-01…E-08 | Invalid-input IV-01…IV-13 |
| Dataset-level | E-09…E-14 | Invalid-input IV-06…IV-09, IV-16 |
| Column-level | E-15…E-24 | Benchmarks + IV-14, IV-15, IV-22 |
| Quality-level | E-25…E-28 | Benchmarks + ten-case T02…T04 |
| User-question | E-29…E-31 | Ten-case T07; not-found rules |
| Security | E-32…E-37 | Injection + formula suites |
| Tool-failure | E-38…E-42 | Invalid-input + status verification |

Two edge cases depend on the undecided `partial` status (E-42) and are flagged in KL-20.

## 5. Open items carried to Session 5

| Item | Why it is open |
|---|---|
| All execution evidence | The integrated implementation has not been run |
| Source access dates | Verification not yet performed; no date fabricated |
| Clean-dataset success fixture | The pure `success` path is unexercised (KL-14) |
| Partial-status behaviour | Implementation undecided (KL-20) |
| Decisions D-01…D-33 approval | Awaiting the Integration Lead |
| Candidate source approvals | Awaiting the Integration Lead |

## 6. Honest status statement

The quality module is **specified and documented, with test plans prepared**. It is **not verified**. The
difference is deliberate and load-bearing: a specification claims what should be true; only
executed tests can claim what is true. Every result table in this deliverable preserves that
distinction, and no cell reads "Pass".

## 7. Recommendation into Session 5

Proceed to execution as soon as the backend implementation is callable against the benchmark
fixtures. Prioritise the four blocking security and correctness gates (RQ-01, RQ-04, RQ-05,
RQ-06), then the not-found and chart-refusal behaviour, then the remaining gates. Treat the
four authoring findings as required talking points in the defense, because they show the
quality layer understands its own methods' limits.
