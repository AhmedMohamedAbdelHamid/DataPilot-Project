# DataPilot Quality Module — Production Documentation

**Module owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Version:** profile_version 0.2 · ruleset rules-2026-07-23
**Status:** documentation of the specified behaviour. Execution evidence is
**Pending execution against the integrated implementation.**

---

## 1. Module purpose

The quality module is DataPilot's correctness and trust layer. It defines what the product may
treat as true about an uploaded dataset, how confidently it may speak about it, where its
knowledge comes from, and where it must stop. It does not build the API, the interface, or the
deployment; it defines the rules those components must satisfy and the evidence by which they
are judged.

## 2. Role ownership

| Owned by this module | Owned elsewhere |
|---|---|
| Approved sources and the source register | Repository, deployment (Integration Lead) |
| Domain taxonomy and data-quality definitions | Safe parser, API, AI wiring (Backend Engineer) |
| `profile_dataset()` and `recommend_chart()` **rules** | Their **implementation** (Backend Engineer) |
| Benchmark datasets and exact expected outputs | Screens and interactions (UI Engineer) |
| Edge cases, error semantics, guardrails | Visual design (UI Engineer) |
| Prompt-injection, formula-injection, invalid-input tests | System architecture (Integration Lead) |
| Traceability model, acceptance criteria, limitations | |

## 3. Scope

**In scope:** bounded CSV datasets within configured limits, for academic and small-business
use. **Out of scope:** arbitrary code or formula execution; very large or private datasets;
AI-generated statistics; automatic cleaning or imputation; high-stakes decisions; unsupported
file types; external data enrichment.

## 4. Architecture relationship

```
Upload → Safe parse → profile_dataset() [deterministic] → quality issues
   → recommend_chart() [deterministic rules] → AI explanation [over the profile only] → export
```

The quality module governs the deterministic stages and constrains the AI stage. The single
architectural invariant: **application code computes every measurable fact; the AI may explain
but never calculate, alter, or invent.**

## 5. Domain taxonomy

29 concepts are defined in `Session_2/final_domain_taxonomy.csv` and
`Session_3/bounded_knowledge/definitions.json`, each with a machine name, detection rule,
calculation rule, risk, product behaviour, UI label, backend field, example, and non-example.
The load-bearing distinction is **identifier vs measurement**: a numeric-looking ID is never
summarised as a number.

## 6. Deterministic profiling rules

Full contract in `Session_2/teammate_handoffs/backend_ai_handoff.md`. Summary:

- Row count excludes the header; percentage denominators are total rows.
- Missing = empty or a D-08 token; never imputed.
- Duplicates = full-row exact match (D-09); never removed.
- Standard deviation = sample, N−1 (D-10); percentiles = linear interpolation (D-21).
- Type inference is conservative and ordered: unknown → boolean → identifier → numeric →
  mixed-type text → datetime → categorical/text.
- Potential outliers = IQR 1.5× (D-11), reported as potential only, requiring ≥ 4 values.
- Every output carries `profile_version`, `ruleset_version`, and a `run_id`.

## 7. Chart recommendation rules

Nine rules (CH-01…CH-09) in `Session_3/bounded_knowledge/chart_rules.json`, carried unchanged
from Session 1 §9.1. Selection is deterministic; the AI explains but cannot override.
Refusal conditions are explicit: no field of the required type, identifier-only grouping,
all-missing columns, high cardinality, or inconsistent dates. Refusals return a reason, never
an empty panel.

## 8. Input contract

`dataset_name`, `parsed_table`, `encoding_metadata`, `delimiter_metadata`, `configured_limits`,
`column_hints` (optional). Preconditions: the file has already passed safe parsing and
size/type validation; no un-parsed bytes reach the profiler.

## 9. Output contract

`dataset_name`, `dataset_version`, `profile_version`, `ruleset_version`, `status`, `rows`,
`columns`, `column_names`, `column_profiles[]`, `missing_values{}`, `duplicates{}`,
`anomalies{}`, `quality_issues[]`, `limitations[]`, `warnings[]`, `processing_metadata{}`,
`error`. Column profiles follow the 14-field contract in Session 1 §8.7 plus emitted
`std_convention` and `percentile_method`.

## 10. Error catalogue

11 flat uppercase codes (D-18) in `Session_3/bounded_knowledge/error_messages.json`, each with
one canonical message, an HTTP suggestion, and retry/clarify/escalate/partial flags. No message
exposes a stack trace, path, provider, or secret.

## 11. Warning catalogue

10 structured warning codes: `all_missing`, `constant_column`, `high_cardinality`,
`mixed_type`, `mixed_date_formats`, `inconsistent_category_spelling`, `formula_like_content`,
`identifier_not_summarized`, `encoding_fallback`, `ragged_rows`. Warnings never reduce the
completeness of results.

## 12. Issue catalogue

10 issue types in `Shared_Checklists/issue_card_catalogue.csv`, each with a card title, body
pattern, and severity source. Every card carries type, severity, and evidence.

## 13. Severity model

Deterministic thresholds (D-29) in `Shared_Checklists/severity_model.csv`. Missing values:
low < 10%, medium 10–30%, high > 30%. Duplicates: low ≤ 1%, medium > 1%. Out-of-range,
negative, mixed-type, mixed-date: medium. Formula content, sensitive data, injection: high.
Severity is never assigned by the AI.

## 14. Source strategy

Approved: S-01, S-02, S-03 (handbook). Candidates: C-04…C-11 (pending approval). Lifecycle:
Identify → Verify → Record → Review → Approve → Use → Recheck. No candidate backs a product
claim until approved. Access dates are recorded only when a source is actually opened; none is
fabricated.

## 15. Traceability model

Two channels (`Session_3/traceability_schema.json`): dataset-specific facts trace to the tool
and version; general guidance traces to an approved source ID. A general source is never cited
as the origin of a dataset value.

## 16. Security controls

Cells are untrusted data, never executed. Formula-leading non-numeric cells neutralized (D-25).
Samples capped at 3 × 60 characters (D-15, D-26) and HTML-escaped. AI context bounded (D-27).
Logs record codes and run IDs, never raw cell values (D-19). In-memory processing only (D-14).

## 17. Prompt-injection controls

Structural separation of computation from explanation; the AI has no path to alter a value.
12 attack cases in `prompt_injection_tests.csv`; two live payloads planted in the survey
benchmark. Expected behaviour: counts unchanged, no prompt revealed, payloads shown only as
samples.

## 18. Formula-injection controls

`formula_neutralization_rules.md` (D-25). Apostrophe-prefix on display and export; original
retained internally; `formula_like_content` warning at high severity. Two negative controls
(`2+2`, numeric `-5`) confirm ordinary values are not over-neutralized.

## 19. Reproducibility controls

Output is a pure function of (data, limits, rules, `profile_version`). Percentile method and
std convention are pinned rather than left to library defaults. Repeated runs on the same input
are byte-identical apart from `run_id`.

## 20. Testing strategy

Five core product tests (Session 2), a 73-row expected-vs-actual comparison (Session 3), a
76-check backend verification (Session 3), a 21-scenario chart verification (Session 3), and a
ten-case evaluation plus injection, formula, and invalid-input suites (Session 4). Expected
values are derived from the exact benchmark CSVs, not estimated.

## 21. Benchmark datasets

Three deterministic datasets (seed 20260723): student performance (102×12), small-business
sales (122×13), research survey (96×12). Each ships with a data dictionary, a known-issues
register, an exact expected profile, and expected chart recommendations.

## 22. Evaluation methodology

Actual output is captured from the integrated implementation and compared field by field
against the expected output within tolerance 1e-6 (D-31). A difference is one of: an
implementation error, a specification ambiguity, or an error in my expected value — all three
are recorded, including defects against my own work.

## 23. Known limitations

22 limitations in `known_limitations_register.csv`, including four discovered while authoring
the benchmarks: the IQR method over-flags discrete columns; an out-of-range value can sit
inside the IQR fences; a mixed-type column suppresses numeric analysis; a multi-format date
column blocks trends.

## 24. Change management

`profile_version` (semantic) changes with the contract; `ruleset_version` (`rules-YYYY-MM-DD`)
changes with rule content (D-33). A threshold change moves the ruleset date without a tool
release. Every output records both, so any result can be traced to the rules that produced it.

## 25. Release acceptance criteria

`Shared_Checklists/acceptance_criteria.csv` and `Session_5/final_acceptance_matrix.csv`.
Blocking gates: deterministic output matches expected within tolerance; no injection payload
alters a value; no formula cell is evaluated; no AI number is absent from the profile.

## 26. Future improvements

Add a clean-dataset fixture for the pure `success` path (KL-14); consider a second anomaly
method to complement IQR on discrete and skewed data; add key-based duplicate detection when a
declared key is available; extend the date policy to offer a user-confirmed format; add a
configurable sensitive-data pattern set. All are post-pilot.
