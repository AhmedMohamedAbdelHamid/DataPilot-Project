# Formula-Injection Neutralization Rules

**Owner:** Ahmad Essam — Knowledge, Tools & Quality Engineer, Team 07
**Backing source:** C-06 (OWASP CSV/formula injection — candidate, pending approval)
**Decision:** D-25
**Status:** specification. Tests in `formula_injection_tests.csv`, **Pending execution.**

---

## 1. The risk

A CSV cell whose text begins with `=`, `+`, `-` or `@` may be interpreted as a formula when
the file is opened or re-exported in spreadsheet software. A value such as
`=cmd|' /C calc'!A1` can, in some configurations, trigger command execution on the opener's
machine. DataPilot never evaluates such content itself, but it exports data and displays
samples, so it can be a *carrier* if it does not neutralize.

## 2. The rule

A non-missing cell is a **formula-injection candidate** when:

- its first character (after trimming leading whitespace) is one of `= + - @`, **and**
- the cell does not parse as a plain number.

The second condition matters. In a numeric column, `-5` is the value negative five, not an
attack. `-15 discount agreed verbally` is text beginning with `-` and is a candidate.

## 3. Neutralization method (D-25)

- **Display and export:** prefix the value with a single apostrophe (`'`). Spreadsheet
  software treats an apostrophe-prefixed cell as literal text and does not evaluate it.
- **Internal storage:** the original value is retained unchanged, so counts, uniqueness, and
  sample provenance are unaffected.
- **Warning:** the column raises `formula_like_content` at severity **high**, with the count of
  affected cells.
- **HTML safety:** independently, `<` and `>` are escaped so no cell renders as markup.

The apostrophe method is chosen over stripping the cell (which would destroy the user's data)
and over escaping alone (which does not prevent evaluation in all spreadsheet software).

## 4. Behaviour table

| Raw value | Candidate? | Displayed / exported as | Warning |
|---|---|---|---|
| `=SUM(A1:A9)` | Yes | `'=SUM(A1:A9)` | formula_like_content |
| `+1-555-0100 call...` | Yes | `'+1-555-0100 call...` | formula_like_content |
| `@customer_ref_88213` | Yes | `'@customer_ref_88213` | formula_like_content |
| `-15 discount agreed...` | Yes | `'-15 discount agreed...` | formula_like_content |
| `=cmd\|' /C calc'!A1` | Yes | `'=cmd\|' /C calc'!A1` | formula_like_content |
| `=HYPERLINK("http://x")` | Yes | `'=HYPERLINK("http://x")` | formula_like_content |
| `2+2` | No (starts with a digit) | `2+2` | none |
| `-5` (numeric column) | No (parses as a number) | `-5` | none |

## 5. Where it applies

| Location | Neutralized? |
|---|---|
| `sample_values` in the profile | Yes |
| Values rendered in the UI | Yes |
| Values written to the exported CSV/JSON | Yes |
| The internal value used for counting and uniqueness | No — original retained |

## 6. Present in the benchmark

The sales benchmark's `notes` column contains four candidates (FI-01 to FI-04 in the test
table). The expected profile flags `formula_like_content` on that column and neutralizes the
four values in `sample_values`. This is the fixture the neutralization tests run against.

## 7. Verification

`formula_injection_tests.csv` defines 10 cases, including the two negative controls (FI-08
`2+2` and FI-10 `-5`) that must **not** be neutralized. All currently **Pending execution.**
